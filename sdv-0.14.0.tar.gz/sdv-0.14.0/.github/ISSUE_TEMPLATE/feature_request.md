---
name: Feature request
about: Request a new feature that you would like to see implemented in SDV
title: ''
labels: new feature, pending review
assignees: ''

---

### Problem Description

<Replace this with a description of the problem that you think SDV should be able to solve and is not solving already>

### Expected behavior

<Replace this a clear and concise description of what you would expect SDV with regards with the described problem. If possible, explain how you would like to interact with SDV and what the outcome of this interaction would be.>

### Additional context

<Please provide any additional context that may be relevant to the issue here. If none, please remove this section.>
