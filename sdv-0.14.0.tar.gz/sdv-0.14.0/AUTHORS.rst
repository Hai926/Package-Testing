Credits
=======

* Manuel Alvarez <manuel@pythiac.com>
* Carles Sala <csala@csail.mit.edu>
* José David Pérez <jose@pythiac.com>
* Andrew Montanez <amontane@mit.edu>
* Kalyan Veeramachaneni <kalyan@csail.mit.edu>
* Plamen Valentinov <plamen@pythiac.com>
