.. _getting_started:

Getting Started
===============

.. toctree::
    :maxdepth: 2

    install
    quickstart
