.. _synthetic_data_metrics:

Synthetic Data Metrics
======================

.. toctree::
    :titlesonly:

    single_table_metrics
    multi_table_metrics
    timeseries_metrics
