.. _single_table_constraints:

Constraints
===========

.. toctree::
    :maxdepth: 2

    handling_constraints
    custom_constraints
