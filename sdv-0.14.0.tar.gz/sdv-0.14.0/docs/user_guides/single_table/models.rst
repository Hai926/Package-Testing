.. _single_table_models:

Models
======

.. toctree::
    :maxdepth: 2

    gaussian_copula
    ctgan
    copulagan
    tvae
