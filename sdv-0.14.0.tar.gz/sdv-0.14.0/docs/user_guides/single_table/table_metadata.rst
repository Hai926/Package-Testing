.. _table_metadata:

Table Metadata
==============

Coming soon!
