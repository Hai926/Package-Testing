.. _relational:

Relational Data
===============

**SDV** supports modeling relational datasets.

.. toctree::
    :maxdepth: 2

    data_description
    models
    constraints
