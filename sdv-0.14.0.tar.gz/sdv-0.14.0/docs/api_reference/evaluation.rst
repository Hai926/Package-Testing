.. _sdv.evaluation:

sdv.evaluation
==============

.. currentmodule:: sdv.evaluation

.. autosummary::
   :toctree: api/

   evaluate
