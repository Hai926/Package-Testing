.. _sdv.metrics.demos:

sdv.metrics.demos
=================

.. currentmodule:: sdv.metrics.demos

.. autosummary::
   :toctree: api/

    load_single_table_demo
    load_multi_table_demo
    load_timeseries_demo
