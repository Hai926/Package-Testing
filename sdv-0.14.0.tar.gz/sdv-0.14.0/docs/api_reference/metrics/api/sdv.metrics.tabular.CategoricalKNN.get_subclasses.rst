﻿sdv.metrics.tabular.CategoricalKNN.get\_subclasses
==================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: CategoricalKNN.get_subclasses