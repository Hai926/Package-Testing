﻿sdv.metrics.tabular.DetectionMetric.get\_subclasses
===================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: DetectionMetric.get_subclasses