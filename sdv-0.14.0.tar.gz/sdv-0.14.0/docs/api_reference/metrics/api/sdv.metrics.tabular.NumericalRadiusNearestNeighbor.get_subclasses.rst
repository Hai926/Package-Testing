﻿sdv.metrics.tabular.NumericalRadiusNearestNeighbor.get\_subclasses
==================================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: NumericalRadiusNearestNeighbor.get_subclasses