﻿sdv.metrics.tabular.DetectionMetric
===================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: DetectionMetric

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~DetectionMetric.__init__
      ~DetectionMetric.compute
      ~DetectionMetric.get_subclasses
      ~DetectionMetric.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~DetectionMetric.goal
      ~DetectionMetric.max_value
      ~DetectionMetric.min_value
      ~DetectionMetric.name
   
   