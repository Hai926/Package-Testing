﻿sdv.metrics.tabular.SVCDetection.get\_subclasses
================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: SVCDetection.get_subclasses