﻿sdv.metrics.tabular.CategoricalSVM.get\_subclasses
==================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: CategoricalSVM.get_subclasses