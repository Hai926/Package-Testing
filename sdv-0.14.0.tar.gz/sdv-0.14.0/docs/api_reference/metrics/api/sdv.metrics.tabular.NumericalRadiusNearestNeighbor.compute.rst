﻿sdv.metrics.tabular.NumericalRadiusNearestNeighbor.compute
==========================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: NumericalRadiusNearestNeighbor.compute