﻿sdv.metrics.relational.MultiSingleTableMetric
=============================================

.. currentmodule:: sdv.metrics.relational

.. autoclass:: MultiSingleTableMetric

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~MultiSingleTableMetric.__init__
      ~MultiSingleTableMetric.compute
      ~MultiSingleTableMetric.get_subclasses
      ~MultiSingleTableMetric.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~MultiSingleTableMetric.single_table_metric
   
   