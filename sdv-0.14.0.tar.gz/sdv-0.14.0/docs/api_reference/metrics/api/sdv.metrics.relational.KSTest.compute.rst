﻿sdv.metrics.relational.KSTest.compute
=====================================

.. currentmodule:: sdv.metrics.relational

.. automethod:: KSTest.compute