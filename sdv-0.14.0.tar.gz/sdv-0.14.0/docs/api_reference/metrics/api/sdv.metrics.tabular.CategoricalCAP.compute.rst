﻿sdv.metrics.tabular.CategoricalCAP.compute
==========================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: CategoricalCAP.compute