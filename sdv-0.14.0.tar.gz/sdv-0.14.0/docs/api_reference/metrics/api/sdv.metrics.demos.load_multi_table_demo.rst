﻿sdv.metrics.demos.load\_multi\_table\_demo
==========================================

.. currentmodule:: sdv.metrics.demos

.. autofunction:: load_multi_table_demo