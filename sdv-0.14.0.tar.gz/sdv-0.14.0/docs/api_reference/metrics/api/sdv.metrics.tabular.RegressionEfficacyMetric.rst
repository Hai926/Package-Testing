﻿sdv.metrics.tabular.RegressionEfficacyMetric
============================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: RegressionEfficacyMetric

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~RegressionEfficacyMetric.SCORER
      ~RegressionEfficacyMetric.__init__
      ~RegressionEfficacyMetric.compute
      ~RegressionEfficacyMetric.get_subclasses
      ~RegressionEfficacyMetric.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~RegressionEfficacyMetric.METRICS
      ~RegressionEfficacyMetric.MODEL
      ~RegressionEfficacyMetric.MODEL_KWARGS
      ~RegressionEfficacyMetric.goal
      ~RegressionEfficacyMetric.max_value
      ~RegressionEfficacyMetric.min_value
      ~RegressionEfficacyMetric.name
   
   