﻿sdv.metrics.tabular.LinearRegression.get\_subclasses
====================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: LinearRegression.get_subclasses