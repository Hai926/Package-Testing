﻿sdv.metrics.timeseries.LSTMDetection
====================================

.. currentmodule:: sdv.metrics.timeseries

.. autoclass:: LSTMDetection

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~LSTMDetection.__init__
      ~LSTMDetection.compute
      ~LSTMDetection.get_subclasses
      ~LSTMDetection.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~LSTMDetection.goal
      ~LSTMDetection.max_value
      ~LSTMDetection.min_value
      ~LSTMDetection.name
   
   