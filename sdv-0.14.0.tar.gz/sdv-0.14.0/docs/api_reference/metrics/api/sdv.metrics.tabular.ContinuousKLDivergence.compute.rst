﻿sdv.metrics.tabular.ContinuousKLDivergence.compute
==================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: ContinuousKLDivergence.compute