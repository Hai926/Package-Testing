﻿sdv.metrics.tabular.NumericalPrivacyMetric
==========================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: NumericalPrivacyMetric

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~NumericalPrivacyMetric.__init__
      ~NumericalPrivacyMetric.compute
      ~NumericalPrivacyMetric.get_subclasses
      ~NumericalPrivacyMetric.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~NumericalPrivacyMetric.LOSS_FUNCTION_KWARGS
      ~NumericalPrivacyMetric.MODEL
      ~NumericalPrivacyMetric.MODEL_KWARGS
      ~NumericalPrivacyMetric.goal
      ~NumericalPrivacyMetric.max_value
      ~NumericalPrivacyMetric.min_value
      ~NumericalPrivacyMetric.name
   
   