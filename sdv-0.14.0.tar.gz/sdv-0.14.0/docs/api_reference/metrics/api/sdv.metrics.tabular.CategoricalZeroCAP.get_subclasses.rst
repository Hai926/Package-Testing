﻿sdv.metrics.tabular.CategoricalZeroCAP.get\_subclasses
======================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: CategoricalZeroCAP.get_subclasses