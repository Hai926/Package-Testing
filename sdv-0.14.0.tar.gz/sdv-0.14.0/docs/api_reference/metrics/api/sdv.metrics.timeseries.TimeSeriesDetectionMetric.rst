﻿sdv.metrics.timeseries.TimeSeriesDetectionMetric
================================================

.. currentmodule:: sdv.metrics.timeseries

.. autoclass:: TimeSeriesDetectionMetric

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TimeSeriesDetectionMetric.__init__
      ~TimeSeriesDetectionMetric.compute
      ~TimeSeriesDetectionMetric.get_subclasses
      ~TimeSeriesDetectionMetric.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~TimeSeriesDetectionMetric.goal
      ~TimeSeriesDetectionMetric.max_value
      ~TimeSeriesDetectionMetric.min_value
      ~TimeSeriesDetectionMetric.name
   
   