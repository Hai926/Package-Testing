﻿sdv.metrics.tabular.CategoricalSVM
==================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: CategoricalSVM

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~CategoricalSVM.__init__
      ~CategoricalSVM.compute
      ~CategoricalSVM.get_subclasses
      ~CategoricalSVM.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CategoricalSVM.ACCURACY_BASE
      ~CategoricalSVM.MODEL_KWARGS
      ~CategoricalSVM.goal
      ~CategoricalSVM.max_value
      ~CategoricalSVM.min_value
      ~CategoricalSVM.name
   
   