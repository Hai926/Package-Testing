﻿sdv.metrics.relational.SVCParentChildDetection.get\_subclasses
==============================================================

.. currentmodule:: sdv.metrics.relational

.. automethod:: SVCParentChildDetection.get_subclasses