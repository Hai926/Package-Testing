﻿sdv.metrics.relational.LogisticDetection.compute
================================================

.. currentmodule:: sdv.metrics.relational

.. automethod:: LogisticDetection.compute