﻿sdv.metrics.tabular.BinaryAdaBoostClassifier.compute
====================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: BinaryAdaBoostClassifier.compute