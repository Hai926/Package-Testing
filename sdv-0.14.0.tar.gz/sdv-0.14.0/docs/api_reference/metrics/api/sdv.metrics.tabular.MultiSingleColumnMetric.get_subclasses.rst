﻿sdv.metrics.tabular.MultiSingleColumnMetric.get\_subclasses
===========================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: MultiSingleColumnMetric.get_subclasses