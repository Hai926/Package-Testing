﻿sdv.metrics.relational.BNLogLikelihood.get\_subclasses
======================================================

.. currentmodule:: sdv.metrics.relational

.. automethod:: BNLogLikelihood.get_subclasses