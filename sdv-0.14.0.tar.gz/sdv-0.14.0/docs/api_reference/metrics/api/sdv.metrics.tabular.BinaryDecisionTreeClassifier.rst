﻿sdv.metrics.tabular.BinaryDecisionTreeClassifier
================================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: BinaryDecisionTreeClassifier

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~BinaryDecisionTreeClassifier.SCORER
      ~BinaryDecisionTreeClassifier.__init__
      ~BinaryDecisionTreeClassifier.compute
      ~BinaryDecisionTreeClassifier.get_subclasses
      ~BinaryDecisionTreeClassifier.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~BinaryDecisionTreeClassifier.METRICS
      ~BinaryDecisionTreeClassifier.MODEL_KWARGS
      ~BinaryDecisionTreeClassifier.goal
      ~BinaryDecisionTreeClassifier.max_value
      ~BinaryDecisionTreeClassifier.min_value
      ~BinaryDecisionTreeClassifier.name
   
   