﻿sdv.metrics.tabular.CategoricalSVM.compute
==========================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: CategoricalSVM.compute