﻿sdv.metrics.tabular.BNLikelihood.get\_subclasses
================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: BNLikelihood.get_subclasses