﻿sdv.metrics.timeseries.LSTMDetection.get\_subclasses
====================================================

.. currentmodule:: sdv.metrics.timeseries

.. automethod:: LSTMDetection.get_subclasses