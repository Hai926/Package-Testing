﻿sdv.metrics.relational.DetectionMetric
======================================

.. currentmodule:: sdv.metrics.relational

.. autoclass:: DetectionMetric

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~DetectionMetric.__init__
      ~DetectionMetric.compute
      ~DetectionMetric.get_subclasses
      ~DetectionMetric.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~DetectionMetric.goal
      ~DetectionMetric.max_value
      ~DetectionMetric.min_value
      ~DetectionMetric.name
   
   