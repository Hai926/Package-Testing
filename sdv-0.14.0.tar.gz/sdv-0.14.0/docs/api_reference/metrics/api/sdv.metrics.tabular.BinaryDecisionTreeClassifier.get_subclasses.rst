﻿sdv.metrics.tabular.BinaryDecisionTreeClassifier.get\_subclasses
================================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: BinaryDecisionTreeClassifier.get_subclasses