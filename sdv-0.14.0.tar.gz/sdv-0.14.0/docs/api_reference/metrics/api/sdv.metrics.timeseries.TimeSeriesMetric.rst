﻿sdv.metrics.timeseries.TimeSeriesMetric
=======================================

.. currentmodule:: sdv.metrics.timeseries

.. autoclass:: TimeSeriesMetric

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TimeSeriesMetric.__init__
      ~TimeSeriesMetric.compute
      ~TimeSeriesMetric.get_subclasses
      ~TimeSeriesMetric.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~TimeSeriesMetric.goal
      ~TimeSeriesMetric.max_value
      ~TimeSeriesMetric.min_value
      ~TimeSeriesMetric.name
   
   