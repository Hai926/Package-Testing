﻿sdv.metrics.timeseries.TimeSeriesEfficacyMetric
===============================================

.. currentmodule:: sdv.metrics.timeseries

.. autoclass:: TimeSeriesEfficacyMetric

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TimeSeriesEfficacyMetric.__init__
      ~TimeSeriesEfficacyMetric.compute
      ~TimeSeriesEfficacyMetric.get_subclasses
      ~TimeSeriesEfficacyMetric.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~TimeSeriesEfficacyMetric.goal
      ~TimeSeriesEfficacyMetric.max_value
      ~TimeSeriesEfficacyMetric.min_value
      ~TimeSeriesEfficacyMetric.name
   
   