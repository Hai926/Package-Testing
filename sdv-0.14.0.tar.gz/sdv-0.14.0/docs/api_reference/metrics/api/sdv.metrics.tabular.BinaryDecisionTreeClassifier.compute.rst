﻿sdv.metrics.tabular.BinaryDecisionTreeClassifier.compute
========================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: BinaryDecisionTreeClassifier.compute