﻿sdv.metrics.relational.DetectionMetric.get\_subclasses
======================================================

.. currentmodule:: sdv.metrics.relational

.. automethod:: DetectionMetric.get_subclasses