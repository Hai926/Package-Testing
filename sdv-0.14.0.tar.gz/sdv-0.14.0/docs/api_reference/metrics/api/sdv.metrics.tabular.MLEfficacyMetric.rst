﻿sdv.metrics.tabular.MLEfficacyMetric
====================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: MLEfficacyMetric

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~MLEfficacyMetric.__init__
      ~MLEfficacyMetric.compute
      ~MLEfficacyMetric.get_subclasses
      ~MLEfficacyMetric.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~MLEfficacyMetric.METRICS
      ~MLEfficacyMetric.MODEL
      ~MLEfficacyMetric.MODEL_KWARGS
      ~MLEfficacyMetric.goal
      ~MLEfficacyMetric.max_value
      ~MLEfficacyMetric.min_value
      ~MLEfficacyMetric.name
   
   