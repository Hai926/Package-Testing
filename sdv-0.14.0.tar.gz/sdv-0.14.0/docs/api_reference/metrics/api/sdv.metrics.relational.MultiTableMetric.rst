﻿sdv.metrics.relational.MultiTableMetric
=======================================

.. currentmodule:: sdv.metrics.relational

.. autoclass:: MultiTableMetric

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~MultiTableMetric.__init__
      ~MultiTableMetric.compute
      ~MultiTableMetric.get_subclasses
      ~MultiTableMetric.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~MultiTableMetric.goal
      ~MultiTableMetric.max_value
      ~MultiTableMetric.min_value
      ~MultiTableMetric.name
   
   