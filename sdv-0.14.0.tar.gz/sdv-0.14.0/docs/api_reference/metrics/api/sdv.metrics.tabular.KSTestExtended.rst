﻿sdv.metrics.tabular.KSTestExtended
==================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: KSTestExtended

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~KSTestExtended.__init__
      ~KSTestExtended.compute
      ~KSTestExtended.get_subclasses
      ~KSTestExtended.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~KSTestExtended.field_types
      ~KSTestExtended.goal
      ~KSTestExtended.max_value
      ~KSTestExtended.min_value
      ~KSTestExtended.name
      ~KSTestExtended.single_column_metric_kwargs
   
   