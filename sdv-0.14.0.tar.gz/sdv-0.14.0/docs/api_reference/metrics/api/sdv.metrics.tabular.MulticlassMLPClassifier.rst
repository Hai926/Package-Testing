﻿sdv.metrics.tabular.MulticlassMLPClassifier
===========================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: MulticlassMLPClassifier

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~MulticlassMLPClassifier.SCORER
      ~MulticlassMLPClassifier.__init__
      ~MulticlassMLPClassifier.compute
      ~MulticlassMLPClassifier.get_subclasses
      ~MulticlassMLPClassifier.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~MulticlassMLPClassifier.METRICS
      ~MulticlassMLPClassifier.MODEL_KWARGS
      ~MulticlassMLPClassifier.goal
      ~MulticlassMLPClassifier.max_value
      ~MulticlassMLPClassifier.min_value
      ~MulticlassMLPClassifier.name
   
   