﻿sdv.metrics.tabular.NumericalSVR.compute
========================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: NumericalSVR.compute