﻿sdv.metrics.relational.BNLogLikelihood
======================================

.. currentmodule:: sdv.metrics.relational

.. autoclass:: BNLogLikelihood

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~BNLogLikelihood.__init__
      ~BNLogLikelihood.compute
      ~BNLogLikelihood.get_subclasses
      ~BNLogLikelihood.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~BNLogLikelihood.goal
      ~BNLogLikelihood.max_value
      ~BNLogLikelihood.min_value
      ~BNLogLikelihood.name
   
   