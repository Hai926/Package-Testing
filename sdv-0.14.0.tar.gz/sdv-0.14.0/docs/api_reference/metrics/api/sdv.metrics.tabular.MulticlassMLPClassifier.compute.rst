﻿sdv.metrics.tabular.MulticlassMLPClassifier.compute
===================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: MulticlassMLPClassifier.compute