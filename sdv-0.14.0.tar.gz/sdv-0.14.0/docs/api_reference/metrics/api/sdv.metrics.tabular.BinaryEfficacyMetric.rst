﻿sdv.metrics.tabular.BinaryEfficacyMetric
========================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: BinaryEfficacyMetric

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~BinaryEfficacyMetric.SCORER
      ~BinaryEfficacyMetric.__init__
      ~BinaryEfficacyMetric.compute
      ~BinaryEfficacyMetric.get_subclasses
      ~BinaryEfficacyMetric.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~BinaryEfficacyMetric.METRICS
      ~BinaryEfficacyMetric.MODEL
      ~BinaryEfficacyMetric.MODEL_KWARGS
      ~BinaryEfficacyMetric.goal
      ~BinaryEfficacyMetric.max_value
      ~BinaryEfficacyMetric.min_value
      ~BinaryEfficacyMetric.name
   
   