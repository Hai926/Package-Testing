﻿sdv.metrics.tabular.CategoricalRF.compute
=========================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: CategoricalRF.compute