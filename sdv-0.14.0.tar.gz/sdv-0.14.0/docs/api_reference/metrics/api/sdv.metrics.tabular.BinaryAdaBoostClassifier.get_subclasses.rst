﻿sdv.metrics.tabular.BinaryAdaBoostClassifier.get\_subclasses
============================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: BinaryAdaBoostClassifier.get_subclasses