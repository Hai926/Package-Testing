﻿sdv.metrics.timeseries.LSTMClassifierEfficacy.get\_subclasses
=============================================================

.. currentmodule:: sdv.metrics.timeseries

.. automethod:: LSTMClassifierEfficacy.get_subclasses