﻿sdv.metrics.tabular.DiscreteKLDivergence.get\_subclasses
========================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: DiscreteKLDivergence.get_subclasses