﻿sdv.metrics.relational.KSTestExtended.compute
=============================================

.. currentmodule:: sdv.metrics.relational

.. automethod:: KSTestExtended.compute