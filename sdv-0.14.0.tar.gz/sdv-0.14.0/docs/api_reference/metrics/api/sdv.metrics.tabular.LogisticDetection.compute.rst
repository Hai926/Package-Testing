﻿sdv.metrics.tabular.LogisticDetection.compute
=============================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: LogisticDetection.compute