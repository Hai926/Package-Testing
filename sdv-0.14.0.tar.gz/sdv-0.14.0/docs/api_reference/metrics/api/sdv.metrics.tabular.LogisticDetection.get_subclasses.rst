﻿sdv.metrics.tabular.LogisticDetection.get\_subclasses
=====================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: LogisticDetection.get_subclasses