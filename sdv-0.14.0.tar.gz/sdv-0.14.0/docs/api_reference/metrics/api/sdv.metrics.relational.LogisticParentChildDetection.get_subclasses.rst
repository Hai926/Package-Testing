﻿sdv.metrics.relational.LogisticParentChildDetection.get\_subclasses
===================================================================

.. currentmodule:: sdv.metrics.relational

.. automethod:: LogisticParentChildDetection.get_subclasses