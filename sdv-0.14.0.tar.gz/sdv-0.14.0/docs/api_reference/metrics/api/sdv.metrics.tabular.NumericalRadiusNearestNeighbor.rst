﻿sdv.metrics.tabular.NumericalRadiusNearestNeighbor
==================================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: NumericalRadiusNearestNeighbor

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~NumericalRadiusNearestNeighbor.__init__
      ~NumericalRadiusNearestNeighbor.compute
      ~NumericalRadiusNearestNeighbor.get_subclasses
      ~NumericalRadiusNearestNeighbor.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~NumericalRadiusNearestNeighbor.LOSS_FUNCTION_KWARGS
      ~NumericalRadiusNearestNeighbor.MODEL_KWARGS
      ~NumericalRadiusNearestNeighbor.goal
      ~NumericalRadiusNearestNeighbor.max_value
      ~NumericalRadiusNearestNeighbor.min_value
      ~NumericalRadiusNearestNeighbor.name
   
   