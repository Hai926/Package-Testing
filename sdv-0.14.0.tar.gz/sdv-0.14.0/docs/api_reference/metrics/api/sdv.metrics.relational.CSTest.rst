﻿sdv.metrics.relational.CSTest
=============================

.. currentmodule:: sdv.metrics.relational

.. autoclass:: CSTest

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~CSTest.__init__
      ~CSTest.compute
      ~CSTest.get_subclasses
      ~CSTest.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CSTest.goal
      ~CSTest.max_value
      ~CSTest.min_value
      ~CSTest.name
   
   