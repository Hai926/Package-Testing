﻿sdv.metrics.tabular.SingleTableMetric.get\_subclasses
=====================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: SingleTableMetric.get_subclasses