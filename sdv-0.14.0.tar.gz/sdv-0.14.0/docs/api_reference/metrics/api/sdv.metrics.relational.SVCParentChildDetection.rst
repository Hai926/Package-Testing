﻿sdv.metrics.relational.SVCParentChildDetection
==============================================

.. currentmodule:: sdv.metrics.relational

.. autoclass:: SVCParentChildDetection

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~SVCParentChildDetection.__init__
      ~SVCParentChildDetection.compute
      ~SVCParentChildDetection.get_subclasses
      ~SVCParentChildDetection.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~SVCParentChildDetection.goal
      ~SVCParentChildDetection.max_value
      ~SVCParentChildDetection.min_value
      ~SVCParentChildDetection.name
   
   