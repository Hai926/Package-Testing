﻿sdv.metrics.demos.load\_timeseries\_demo
========================================

.. currentmodule:: sdv.metrics.demos

.. autofunction:: load_timeseries_demo