﻿sdv.metrics.tabular.KSTestExtended.compute
==========================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: KSTestExtended.compute