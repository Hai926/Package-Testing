﻿sdv.metrics.tabular.NumericalMLP.compute
========================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: NumericalMLP.compute