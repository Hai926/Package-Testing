﻿sdv.metrics.tabular.SingleTableMetric
=====================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: SingleTableMetric

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~SingleTableMetric.__init__
      ~SingleTableMetric.compute
      ~SingleTableMetric.get_subclasses
      ~SingleTableMetric.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~SingleTableMetric.goal
      ~SingleTableMetric.max_value
      ~SingleTableMetric.min_value
      ~SingleTableMetric.name
   
   