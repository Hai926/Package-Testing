﻿sdv.metrics.tabular.CategoricalNB
=================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: CategoricalNB

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~CategoricalNB.__init__
      ~CategoricalNB.compute
      ~CategoricalNB.get_subclasses
      ~CategoricalNB.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CategoricalNB.ACCURACY_BASE
      ~CategoricalNB.MODEL_KWARGS
      ~CategoricalNB.goal
      ~CategoricalNB.max_value
      ~CategoricalNB.min_value
      ~CategoricalNB.name
   
   