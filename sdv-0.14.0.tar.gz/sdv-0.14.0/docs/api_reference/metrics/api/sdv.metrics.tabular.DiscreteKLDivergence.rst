﻿sdv.metrics.tabular.DiscreteKLDivergence
========================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: DiscreteKLDivergence

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~DiscreteKLDivergence.__init__
      ~DiscreteKLDivergence.compute
      ~DiscreteKLDivergence.get_subclasses
      ~DiscreteKLDivergence.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~DiscreteKLDivergence.column_pairs_metric_kwargs
      ~DiscreteKLDivergence.field_types
      ~DiscreteKLDivergence.goal
      ~DiscreteKLDivergence.max_value
      ~DiscreteKLDivergence.min_value
      ~DiscreteKLDivergence.name
   
   