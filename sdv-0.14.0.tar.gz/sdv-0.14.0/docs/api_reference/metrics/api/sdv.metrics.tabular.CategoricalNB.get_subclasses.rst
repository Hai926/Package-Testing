﻿sdv.metrics.tabular.CategoricalNB.get\_subclasses
=================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: CategoricalNB.get_subclasses