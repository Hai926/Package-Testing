﻿sdv.metrics.tabular.MulticlassDecisionTreeClassifier.get\_subclasses
====================================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: MulticlassDecisionTreeClassifier.get_subclasses