﻿sdv.metrics.tabular.MLPRegressor.compute
========================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: MLPRegressor.compute