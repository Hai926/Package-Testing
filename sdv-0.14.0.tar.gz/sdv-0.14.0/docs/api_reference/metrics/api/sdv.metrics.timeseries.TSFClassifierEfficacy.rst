﻿sdv.metrics.timeseries.TSFClassifierEfficacy
============================================

.. currentmodule:: sdv.metrics.timeseries

.. autoclass:: TSFClassifierEfficacy

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TSFClassifierEfficacy.__init__
      ~TSFClassifierEfficacy.compute
      ~TSFClassifierEfficacy.get_subclasses
      ~TSFClassifierEfficacy.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~TSFClassifierEfficacy.goal
      ~TSFClassifierEfficacy.max_value
      ~TSFClassifierEfficacy.min_value
      ~TSFClassifierEfficacy.name
   
   