﻿sdv.metrics.tabular.NumericalMLP.get\_subclasses
================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: NumericalMLP.get_subclasses