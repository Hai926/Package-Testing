﻿sdv.metrics.tabular.MLPRegressor.get\_subclasses
================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: MLPRegressor.get_subclasses