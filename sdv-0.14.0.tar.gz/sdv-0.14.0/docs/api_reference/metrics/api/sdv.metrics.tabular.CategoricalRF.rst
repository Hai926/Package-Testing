﻿sdv.metrics.tabular.CategoricalRF
=================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: CategoricalRF

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~CategoricalRF.__init__
      ~CategoricalRF.compute
      ~CategoricalRF.get_subclasses
      ~CategoricalRF.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CategoricalRF.ACCURACY_BASE
      ~CategoricalRF.MODEL_KWARGS
      ~CategoricalRF.goal
      ~CategoricalRF.max_value
      ~CategoricalRF.min_value
      ~CategoricalRF.name
   
   