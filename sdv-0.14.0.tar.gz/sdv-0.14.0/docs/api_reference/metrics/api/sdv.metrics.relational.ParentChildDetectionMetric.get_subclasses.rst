﻿sdv.metrics.relational.ParentChildDetectionMetric.get\_subclasses
=================================================================

.. currentmodule:: sdv.metrics.relational

.. automethod:: ParentChildDetectionMetric.get_subclasses