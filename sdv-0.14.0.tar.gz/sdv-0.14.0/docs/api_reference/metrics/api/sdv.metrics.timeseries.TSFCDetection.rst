﻿sdv.metrics.timeseries.TSFCDetection
====================================

.. currentmodule:: sdv.metrics.timeseries

.. autoclass:: TSFCDetection

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TSFCDetection.__init__
      ~TSFCDetection.compute
      ~TSFCDetection.get_subclasses
      ~TSFCDetection.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~TSFCDetection.goal
      ~TSFCDetection.max_value
      ~TSFCDetection.min_value
      ~TSFCDetection.name
   
   