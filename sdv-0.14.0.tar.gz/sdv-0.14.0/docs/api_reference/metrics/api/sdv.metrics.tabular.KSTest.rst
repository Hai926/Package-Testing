﻿sdv.metrics.tabular.KSTest
==========================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: KSTest

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~KSTest.__init__
      ~KSTest.compute
      ~KSTest.get_subclasses
      ~KSTest.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~KSTest.field_types
      ~KSTest.goal
      ~KSTest.max_value
      ~KSTest.min_value
      ~KSTest.name
      ~KSTest.single_column_metric_kwargs
   
   