﻿sdv.metrics.tabular.LinearRegression.compute
============================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: LinearRegression.compute