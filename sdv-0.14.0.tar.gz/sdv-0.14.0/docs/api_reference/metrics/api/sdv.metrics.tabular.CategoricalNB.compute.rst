﻿sdv.metrics.tabular.CategoricalNB.compute
=========================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: CategoricalNB.compute