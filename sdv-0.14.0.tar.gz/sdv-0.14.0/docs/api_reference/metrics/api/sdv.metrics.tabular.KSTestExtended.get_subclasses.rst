﻿sdv.metrics.tabular.KSTestExtended.get\_subclasses
==================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: KSTestExtended.get_subclasses