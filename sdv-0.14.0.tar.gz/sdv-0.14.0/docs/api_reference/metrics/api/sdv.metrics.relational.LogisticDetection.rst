﻿sdv.metrics.relational.LogisticDetection
========================================

.. currentmodule:: sdv.metrics.relational

.. autoclass:: LogisticDetection

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~LogisticDetection.__init__
      ~LogisticDetection.compute
      ~LogisticDetection.get_subclasses
      ~LogisticDetection.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~LogisticDetection.goal
      ~LogisticDetection.max_value
      ~LogisticDetection.min_value
      ~LogisticDetection.name
   
   