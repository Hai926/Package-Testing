﻿sdv.metrics.tabular.CategoricalRF.get\_subclasses
=================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: CategoricalRF.get_subclasses