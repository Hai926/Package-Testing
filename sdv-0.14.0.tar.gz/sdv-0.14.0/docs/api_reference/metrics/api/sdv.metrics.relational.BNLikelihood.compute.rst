﻿sdv.metrics.relational.BNLikelihood.compute
===========================================

.. currentmodule:: sdv.metrics.relational

.. automethod:: BNLikelihood.compute