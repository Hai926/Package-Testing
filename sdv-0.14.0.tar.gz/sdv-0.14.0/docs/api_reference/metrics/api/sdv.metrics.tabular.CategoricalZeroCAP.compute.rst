﻿sdv.metrics.tabular.CategoricalZeroCAP.compute
==============================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: CategoricalZeroCAP.compute