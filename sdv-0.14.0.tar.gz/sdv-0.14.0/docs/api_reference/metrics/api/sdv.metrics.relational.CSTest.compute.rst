﻿sdv.metrics.relational.CSTest.compute
=====================================

.. currentmodule:: sdv.metrics.relational

.. automethod:: CSTest.compute