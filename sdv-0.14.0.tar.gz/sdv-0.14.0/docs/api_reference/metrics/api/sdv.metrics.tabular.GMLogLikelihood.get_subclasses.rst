﻿sdv.metrics.tabular.GMLogLikelihood.get\_subclasses
===================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: GMLogLikelihood.get_subclasses