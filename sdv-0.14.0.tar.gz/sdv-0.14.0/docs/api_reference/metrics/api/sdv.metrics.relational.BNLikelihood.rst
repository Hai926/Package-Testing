﻿sdv.metrics.relational.BNLikelihood
===================================

.. currentmodule:: sdv.metrics.relational

.. autoclass:: BNLikelihood

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~BNLikelihood.__init__
      ~BNLikelihood.compute
      ~BNLikelihood.get_subclasses
      ~BNLikelihood.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~BNLikelihood.goal
      ~BNLikelihood.max_value
      ~BNLikelihood.min_value
      ~BNLikelihood.name
   
   