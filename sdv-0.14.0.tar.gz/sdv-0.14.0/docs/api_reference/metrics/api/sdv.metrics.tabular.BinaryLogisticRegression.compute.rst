﻿sdv.metrics.tabular.BinaryLogisticRegression.compute
====================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: BinaryLogisticRegression.compute