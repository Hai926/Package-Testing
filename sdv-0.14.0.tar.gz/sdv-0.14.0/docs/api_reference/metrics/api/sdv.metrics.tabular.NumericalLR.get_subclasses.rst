﻿sdv.metrics.tabular.NumericalLR.get\_subclasses
===============================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: NumericalLR.get_subclasses