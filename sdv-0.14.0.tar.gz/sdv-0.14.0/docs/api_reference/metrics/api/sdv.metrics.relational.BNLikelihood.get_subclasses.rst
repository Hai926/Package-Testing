﻿sdv.metrics.relational.BNLikelihood.get\_subclasses
===================================================

.. currentmodule:: sdv.metrics.relational

.. automethod:: BNLikelihood.get_subclasses