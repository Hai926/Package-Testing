﻿sdv.metrics.tabular.CategoricalGeneralizedCAP.get\_subclasses
=============================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: CategoricalGeneralizedCAP.get_subclasses