﻿sdv.metrics.relational.BNLogLikelihood.compute
==============================================

.. currentmodule:: sdv.metrics.relational

.. automethod:: BNLogLikelihood.compute