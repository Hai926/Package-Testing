﻿sdv.metrics.timeseries.TSFClassifierEfficacy.compute
====================================================

.. currentmodule:: sdv.metrics.timeseries

.. automethod:: TSFClassifierEfficacy.compute