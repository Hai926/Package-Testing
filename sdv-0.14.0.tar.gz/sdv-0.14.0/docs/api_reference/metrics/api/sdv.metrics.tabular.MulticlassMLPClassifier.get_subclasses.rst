﻿sdv.metrics.tabular.MulticlassMLPClassifier.get\_subclasses
===========================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: MulticlassMLPClassifier.get_subclasses