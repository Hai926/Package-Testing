﻿sdv.metrics.tabular.MLEfficacyMetric.get\_subclasses
====================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: MLEfficacyMetric.get_subclasses