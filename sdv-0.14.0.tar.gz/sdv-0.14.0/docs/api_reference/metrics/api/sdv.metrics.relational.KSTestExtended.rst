﻿sdv.metrics.relational.KSTestExtended
=====================================

.. currentmodule:: sdv.metrics.relational

.. autoclass:: KSTestExtended

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~KSTestExtended.__init__
      ~KSTestExtended.compute
      ~KSTestExtended.get_subclasses
      ~KSTestExtended.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~KSTestExtended.goal
      ~KSTestExtended.max_value
      ~KSTestExtended.min_value
      ~KSTestExtended.name
   
   