﻿sdv.metrics.tabular.MultiSingleColumnMetric
===========================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: MultiSingleColumnMetric

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~MultiSingleColumnMetric.__init__
      ~MultiSingleColumnMetric.compute
      ~MultiSingleColumnMetric.get_subclasses
      ~MultiSingleColumnMetric.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~MultiSingleColumnMetric.field_types
      ~MultiSingleColumnMetric.single_column_metric
      ~MultiSingleColumnMetric.single_column_metric_kwargs
   
   