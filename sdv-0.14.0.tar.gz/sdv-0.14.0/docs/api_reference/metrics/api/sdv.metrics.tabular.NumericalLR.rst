﻿sdv.metrics.tabular.NumericalLR
===============================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: NumericalLR

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~NumericalLR.__init__
      ~NumericalLR.compute
      ~NumericalLR.get_subclasses
      ~NumericalLR.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~NumericalLR.LOSS_FUNCTION_KWARGS
      ~NumericalLR.MODEL_KWARGS
      ~NumericalLR.goal
      ~NumericalLR.max_value
      ~NumericalLR.min_value
      ~NumericalLR.name
   
   