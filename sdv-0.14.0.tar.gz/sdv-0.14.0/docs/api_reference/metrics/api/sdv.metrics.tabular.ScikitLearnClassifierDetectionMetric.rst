﻿sdv.metrics.tabular.ScikitLearnClassifierDetectionMetric
========================================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: ScikitLearnClassifierDetectionMetric

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~ScikitLearnClassifierDetectionMetric.__init__
      ~ScikitLearnClassifierDetectionMetric.compute
      ~ScikitLearnClassifierDetectionMetric.get_subclasses
      ~ScikitLearnClassifierDetectionMetric.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~ScikitLearnClassifierDetectionMetric.goal
      ~ScikitLearnClassifierDetectionMetric.max_value
      ~ScikitLearnClassifierDetectionMetric.min_value
      ~ScikitLearnClassifierDetectionMetric.name
   
   