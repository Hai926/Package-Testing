﻿sdv.metrics.relational.SVCDetection.compute
===========================================

.. currentmodule:: sdv.metrics.relational

.. automethod:: SVCDetection.compute