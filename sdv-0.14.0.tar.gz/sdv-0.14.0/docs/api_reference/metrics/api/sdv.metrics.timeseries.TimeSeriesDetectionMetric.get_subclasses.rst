﻿sdv.metrics.timeseries.TimeSeriesDetectionMetric.get\_subclasses
================================================================

.. currentmodule:: sdv.metrics.timeseries

.. automethod:: TimeSeriesDetectionMetric.get_subclasses