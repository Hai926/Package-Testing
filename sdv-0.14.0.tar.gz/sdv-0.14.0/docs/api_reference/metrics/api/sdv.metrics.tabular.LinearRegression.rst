﻿sdv.metrics.tabular.LinearRegression
====================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: LinearRegression

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~LinearRegression.SCORER
      ~LinearRegression.__init__
      ~LinearRegression.compute
      ~LinearRegression.get_subclasses
      ~LinearRegression.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~LinearRegression.METRICS
      ~LinearRegression.MODEL_KWARGS
      ~LinearRegression.goal
      ~LinearRegression.max_value
      ~LinearRegression.min_value
      ~LinearRegression.name
   
   