﻿sdv.metrics.tabular.BinaryMLPClassifier.get\_subclasses
=======================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: BinaryMLPClassifier.get_subclasses