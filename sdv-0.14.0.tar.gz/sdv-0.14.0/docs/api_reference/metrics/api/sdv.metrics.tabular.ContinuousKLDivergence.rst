﻿sdv.metrics.tabular.ContinuousKLDivergence
==========================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: ContinuousKLDivergence

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~ContinuousKLDivergence.__init__
      ~ContinuousKLDivergence.compute
      ~ContinuousKLDivergence.get_subclasses
      ~ContinuousKLDivergence.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~ContinuousKLDivergence.column_pairs_metric_kwargs
      ~ContinuousKLDivergence.field_types
      ~ContinuousKLDivergence.goal
      ~ContinuousKLDivergence.max_value
      ~ContinuousKLDivergence.min_value
      ~ContinuousKLDivergence.name
   
   