﻿sdv.metrics.tabular.MulticlassEfficacyMetric
============================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: MulticlassEfficacyMetric

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~MulticlassEfficacyMetric.SCORER
      ~MulticlassEfficacyMetric.__init__
      ~MulticlassEfficacyMetric.compute
      ~MulticlassEfficacyMetric.get_subclasses
      ~MulticlassEfficacyMetric.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~MulticlassEfficacyMetric.METRICS
      ~MulticlassEfficacyMetric.MODEL
      ~MulticlassEfficacyMetric.MODEL_KWARGS
      ~MulticlassEfficacyMetric.goal
      ~MulticlassEfficacyMetric.max_value
      ~MulticlassEfficacyMetric.min_value
      ~MulticlassEfficacyMetric.name
   
   