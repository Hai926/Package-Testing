﻿sdv.metrics.tabular.BinaryEfficacyMetric.get\_subclasses
========================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: BinaryEfficacyMetric.get_subclasses