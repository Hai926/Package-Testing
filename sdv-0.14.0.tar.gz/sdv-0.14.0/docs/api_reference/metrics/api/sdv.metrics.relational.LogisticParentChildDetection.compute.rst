﻿sdv.metrics.relational.LogisticParentChildDetection.compute
===========================================================

.. currentmodule:: sdv.metrics.relational

.. automethod:: LogisticParentChildDetection.compute