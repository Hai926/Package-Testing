﻿sdv.metrics.tabular.CategoricalCAP
==================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: CategoricalCAP

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~CategoricalCAP.__init__
      ~CategoricalCAP.compute
      ~CategoricalCAP.get_subclasses
      ~CategoricalCAP.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CategoricalCAP.ACCURACY_BASE
      ~CategoricalCAP.MODEL_KWARGS
      ~CategoricalCAP.goal
      ~CategoricalCAP.max_value
      ~CategoricalCAP.min_value
      ~CategoricalCAP.name
   
   