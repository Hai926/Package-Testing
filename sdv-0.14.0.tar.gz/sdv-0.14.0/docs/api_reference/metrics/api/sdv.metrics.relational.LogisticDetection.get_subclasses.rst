﻿sdv.metrics.relational.LogisticDetection.get\_subclasses
========================================================

.. currentmodule:: sdv.metrics.relational

.. automethod:: LogisticDetection.get_subclasses