﻿sdv.metrics.tabular.KSTest.get\_subclasses
==========================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: KSTest.get_subclasses