﻿sdv.metrics.relational.ParentChildDetectionMetric
=================================================

.. currentmodule:: sdv.metrics.relational

.. autoclass:: ParentChildDetectionMetric

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~ParentChildDetectionMetric.__init__
      ~ParentChildDetectionMetric.compute
      ~ParentChildDetectionMetric.get_subclasses
      ~ParentChildDetectionMetric.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~ParentChildDetectionMetric.single_table_metric
   
   