﻿sdv.metrics.tabular.CategoricalKNN.compute
==========================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: CategoricalKNN.compute