﻿sdv.metrics.relational.MultiSingleTableMetric.get\_subclasses
=============================================================

.. currentmodule:: sdv.metrics.relational

.. automethod:: MultiSingleTableMetric.get_subclasses