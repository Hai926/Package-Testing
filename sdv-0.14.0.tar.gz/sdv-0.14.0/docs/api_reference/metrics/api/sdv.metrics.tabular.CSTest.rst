﻿sdv.metrics.tabular.CSTest
==========================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: CSTest

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~CSTest.__init__
      ~CSTest.compute
      ~CSTest.get_subclasses
      ~CSTest.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CSTest.field_types
      ~CSTest.goal
      ~CSTest.max_value
      ~CSTest.min_value
      ~CSTest.name
      ~CSTest.single_column_metric_kwargs
   
   