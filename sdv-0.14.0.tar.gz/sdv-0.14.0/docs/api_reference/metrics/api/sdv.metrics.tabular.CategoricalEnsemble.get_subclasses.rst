﻿sdv.metrics.tabular.CategoricalEnsemble.get\_subclasses
=======================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: CategoricalEnsemble.get_subclasses