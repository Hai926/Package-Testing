﻿sdv.metrics.tabular.KSTest.compute
==================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: KSTest.compute