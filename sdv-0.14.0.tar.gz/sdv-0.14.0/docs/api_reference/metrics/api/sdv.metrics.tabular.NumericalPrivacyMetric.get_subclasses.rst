﻿sdv.metrics.tabular.NumericalPrivacyMetric.get\_subclasses
==========================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: NumericalPrivacyMetric.get_subclasses