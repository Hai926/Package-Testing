﻿sdv.metrics.tabular.CategoricalZeroCAP
======================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: CategoricalZeroCAP

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~CategoricalZeroCAP.__init__
      ~CategoricalZeroCAP.compute
      ~CategoricalZeroCAP.get_subclasses
      ~CategoricalZeroCAP.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CategoricalZeroCAP.ACCURACY_BASE
      ~CategoricalZeroCAP.MODEL_KWARGS
      ~CategoricalZeroCAP.goal
      ~CategoricalZeroCAP.max_value
      ~CategoricalZeroCAP.min_value
      ~CategoricalZeroCAP.name
   
   