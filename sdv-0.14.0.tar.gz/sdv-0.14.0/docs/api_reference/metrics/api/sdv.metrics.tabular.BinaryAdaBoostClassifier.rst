﻿sdv.metrics.tabular.BinaryAdaBoostClassifier
============================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: BinaryAdaBoostClassifier

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~BinaryAdaBoostClassifier.SCORER
      ~BinaryAdaBoostClassifier.__init__
      ~BinaryAdaBoostClassifier.compute
      ~BinaryAdaBoostClassifier.get_subclasses
      ~BinaryAdaBoostClassifier.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~BinaryAdaBoostClassifier.METRICS
      ~BinaryAdaBoostClassifier.MODEL_KWARGS
      ~BinaryAdaBoostClassifier.goal
      ~BinaryAdaBoostClassifier.max_value
      ~BinaryAdaBoostClassifier.min_value
      ~BinaryAdaBoostClassifier.name
   
   