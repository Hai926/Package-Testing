﻿sdv.metrics.tabular.CategoricalEnsemble.compute
===============================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: CategoricalEnsemble.compute