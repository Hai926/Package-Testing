﻿sdv.metrics.timeseries.TimeSeriesMetric.get\_subclasses
=======================================================

.. currentmodule:: sdv.metrics.timeseries

.. automethod:: TimeSeriesMetric.get_subclasses