﻿sdv.metrics.tabular.CSTest.compute
==================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: CSTest.compute