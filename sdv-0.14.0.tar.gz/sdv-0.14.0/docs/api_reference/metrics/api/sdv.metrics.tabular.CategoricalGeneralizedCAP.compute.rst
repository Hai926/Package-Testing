﻿sdv.metrics.tabular.CategoricalGeneralizedCAP.compute
=====================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: CategoricalGeneralizedCAP.compute