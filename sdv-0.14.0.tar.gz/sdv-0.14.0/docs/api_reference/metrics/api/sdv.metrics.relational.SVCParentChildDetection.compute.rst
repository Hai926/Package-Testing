﻿sdv.metrics.relational.SVCParentChildDetection.compute
======================================================

.. currentmodule:: sdv.metrics.relational

.. automethod:: SVCParentChildDetection.compute