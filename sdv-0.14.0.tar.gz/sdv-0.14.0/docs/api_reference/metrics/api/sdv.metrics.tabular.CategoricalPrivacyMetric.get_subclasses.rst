﻿sdv.metrics.tabular.CategoricalPrivacyMetric.get\_subclasses
============================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: CategoricalPrivacyMetric.get_subclasses