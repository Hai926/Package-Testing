﻿sdv.metrics.tabular.BNLogLikelihood.get\_subclasses
===================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: BNLogLikelihood.get_subclasses