﻿sdv.metrics.tabular.SVCDetection.compute
========================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: SVCDetection.compute