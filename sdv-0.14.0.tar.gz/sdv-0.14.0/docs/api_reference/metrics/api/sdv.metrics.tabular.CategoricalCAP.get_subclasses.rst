﻿sdv.metrics.tabular.CategoricalCAP.get\_subclasses
==================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: CategoricalCAP.get_subclasses