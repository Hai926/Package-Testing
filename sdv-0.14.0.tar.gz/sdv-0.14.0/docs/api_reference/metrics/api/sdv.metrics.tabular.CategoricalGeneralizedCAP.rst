﻿sdv.metrics.tabular.CategoricalGeneralizedCAP
=============================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: CategoricalGeneralizedCAP

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~CategoricalGeneralizedCAP.__init__
      ~CategoricalGeneralizedCAP.compute
      ~CategoricalGeneralizedCAP.get_subclasses
      ~CategoricalGeneralizedCAP.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CategoricalGeneralizedCAP.ACCURACY_BASE
      ~CategoricalGeneralizedCAP.MODEL_KWARGS
      ~CategoricalGeneralizedCAP.goal
      ~CategoricalGeneralizedCAP.max_value
      ~CategoricalGeneralizedCAP.min_value
      ~CategoricalGeneralizedCAP.name
   
   