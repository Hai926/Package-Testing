﻿sdv.metrics.relational.MultiTableMetric.get\_subclasses
=======================================================

.. currentmodule:: sdv.metrics.relational

.. automethod:: MultiTableMetric.get_subclasses