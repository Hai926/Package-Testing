﻿sdv.metrics.relational.KSTest
=============================

.. currentmodule:: sdv.metrics.relational

.. autoclass:: KSTest

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~KSTest.__init__
      ~KSTest.compute
      ~KSTest.get_subclasses
      ~KSTest.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~KSTest.goal
      ~KSTest.max_value
      ~KSTest.min_value
      ~KSTest.name
   
   