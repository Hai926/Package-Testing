﻿sdv.metrics.tabular.MultiColumnPairsMetric
==========================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: MultiColumnPairsMetric

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~MultiColumnPairsMetric.__init__
      ~MultiColumnPairsMetric.compute
      ~MultiColumnPairsMetric.get_subclasses
      ~MultiColumnPairsMetric.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~MultiColumnPairsMetric.column_pairs_metric
      ~MultiColumnPairsMetric.column_pairs_metric_kwargs
      ~MultiColumnPairsMetric.field_types
   
   