﻿sdv.metrics.tabular.ScikitLearnClassifierDetectionMetric.get\_subclasses
========================================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: ScikitLearnClassifierDetectionMetric.get_subclasses