﻿sdv.metrics.tabular.DiscreteKLDivergence.compute
================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: DiscreteKLDivergence.compute