﻿sdv.metrics.tabular.MLPRegressor
================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: MLPRegressor

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~MLPRegressor.SCORER
      ~MLPRegressor.__init__
      ~MLPRegressor.compute
      ~MLPRegressor.get_subclasses
      ~MLPRegressor.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~MLPRegressor.METRICS
      ~MLPRegressor.MODEL_KWARGS
      ~MLPRegressor.goal
      ~MLPRegressor.max_value
      ~MLPRegressor.min_value
      ~MLPRegressor.name
   
   