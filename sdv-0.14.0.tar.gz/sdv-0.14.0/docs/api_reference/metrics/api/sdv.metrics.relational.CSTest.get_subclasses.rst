﻿sdv.metrics.relational.CSTest.get\_subclasses
=============================================

.. currentmodule:: sdv.metrics.relational

.. automethod:: CSTest.get_subclasses