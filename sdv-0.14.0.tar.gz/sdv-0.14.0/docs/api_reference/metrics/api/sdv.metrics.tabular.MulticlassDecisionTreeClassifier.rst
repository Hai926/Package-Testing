﻿sdv.metrics.tabular.MulticlassDecisionTreeClassifier
====================================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: MulticlassDecisionTreeClassifier

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~MulticlassDecisionTreeClassifier.SCORER
      ~MulticlassDecisionTreeClassifier.__init__
      ~MulticlassDecisionTreeClassifier.compute
      ~MulticlassDecisionTreeClassifier.get_subclasses
      ~MulticlassDecisionTreeClassifier.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~MulticlassDecisionTreeClassifier.METRICS
      ~MulticlassDecisionTreeClassifier.MODEL_KWARGS
      ~MulticlassDecisionTreeClassifier.goal
      ~MulticlassDecisionTreeClassifier.max_value
      ~MulticlassDecisionTreeClassifier.min_value
      ~MulticlassDecisionTreeClassifier.name
   
   