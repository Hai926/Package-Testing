﻿sdv.metrics.demos.load\_single\_table\_demo
===========================================

.. currentmodule:: sdv.metrics.demos

.. autofunction:: load_single_table_demo