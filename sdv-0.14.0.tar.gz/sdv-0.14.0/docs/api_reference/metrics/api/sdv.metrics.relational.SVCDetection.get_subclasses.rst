﻿sdv.metrics.relational.SVCDetection.get\_subclasses
===================================================

.. currentmodule:: sdv.metrics.relational

.. automethod:: SVCDetection.get_subclasses