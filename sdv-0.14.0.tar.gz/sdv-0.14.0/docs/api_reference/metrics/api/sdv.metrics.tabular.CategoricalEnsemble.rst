﻿sdv.metrics.tabular.CategoricalEnsemble
=======================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: CategoricalEnsemble

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~CategoricalEnsemble.__init__
      ~CategoricalEnsemble.compute
      ~CategoricalEnsemble.get_subclasses
      ~CategoricalEnsemble.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CategoricalEnsemble.ACCURACY_BASE
      ~CategoricalEnsemble.MODEL_KWARGS
      ~CategoricalEnsemble.goal
      ~CategoricalEnsemble.max_value
      ~CategoricalEnsemble.min_value
      ~CategoricalEnsemble.name
   
   