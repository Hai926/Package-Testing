﻿sdv.metrics.tabular.BinaryMLPClassifier
=======================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: BinaryMLPClassifier

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~BinaryMLPClassifier.SCORER
      ~BinaryMLPClassifier.__init__
      ~BinaryMLPClassifier.compute
      ~BinaryMLPClassifier.get_subclasses
      ~BinaryMLPClassifier.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~BinaryMLPClassifier.METRICS
      ~BinaryMLPClassifier.MODEL_KWARGS
      ~BinaryMLPClassifier.goal
      ~BinaryMLPClassifier.max_value
      ~BinaryMLPClassifier.min_value
      ~BinaryMLPClassifier.name
   
   