﻿sdv.metrics.tabular.BNLogLikelihood.compute
===========================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: BNLogLikelihood.compute