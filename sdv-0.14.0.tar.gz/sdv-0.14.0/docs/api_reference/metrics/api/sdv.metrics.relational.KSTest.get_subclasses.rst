﻿sdv.metrics.relational.KSTest.get\_subclasses
=============================================

.. currentmodule:: sdv.metrics.relational

.. automethod:: KSTest.get_subclasses