﻿sdv.metrics.tabular.BNLikelihood.compute
========================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: BNLikelihood.compute