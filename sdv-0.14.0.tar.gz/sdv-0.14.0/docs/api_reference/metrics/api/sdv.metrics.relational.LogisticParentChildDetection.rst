﻿sdv.metrics.relational.LogisticParentChildDetection
===================================================

.. currentmodule:: sdv.metrics.relational

.. autoclass:: LogisticParentChildDetection

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~LogisticParentChildDetection.__init__
      ~LogisticParentChildDetection.compute
      ~LogisticParentChildDetection.get_subclasses
      ~LogisticParentChildDetection.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~LogisticParentChildDetection.goal
      ~LogisticParentChildDetection.max_value
      ~LogisticParentChildDetection.min_value
      ~LogisticParentChildDetection.name
   
   