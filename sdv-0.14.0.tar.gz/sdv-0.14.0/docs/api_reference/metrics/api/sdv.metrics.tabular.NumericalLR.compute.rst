﻿sdv.metrics.tabular.NumericalLR.compute
=======================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: NumericalLR.compute