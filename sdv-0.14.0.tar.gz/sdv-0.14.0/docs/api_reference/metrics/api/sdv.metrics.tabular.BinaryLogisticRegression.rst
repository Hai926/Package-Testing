﻿sdv.metrics.tabular.BinaryLogisticRegression
============================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: BinaryLogisticRegression

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~BinaryLogisticRegression.SCORER
      ~BinaryLogisticRegression.__init__
      ~BinaryLogisticRegression.compute
      ~BinaryLogisticRegression.get_subclasses
      ~BinaryLogisticRegression.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~BinaryLogisticRegression.METRICS
      ~BinaryLogisticRegression.MODEL_KWARGS
      ~BinaryLogisticRegression.goal
      ~BinaryLogisticRegression.max_value
      ~BinaryLogisticRegression.min_value
      ~BinaryLogisticRegression.name
   
   