﻿sdv.metrics.timeseries.TimeSeriesEfficacyMetric.get\_subclasses
===============================================================

.. currentmodule:: sdv.metrics.timeseries

.. automethod:: TimeSeriesEfficacyMetric.get_subclasses