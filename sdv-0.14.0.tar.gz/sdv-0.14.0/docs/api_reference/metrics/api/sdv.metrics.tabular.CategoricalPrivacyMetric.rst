﻿sdv.metrics.tabular.CategoricalPrivacyMetric
============================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: CategoricalPrivacyMetric

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~CategoricalPrivacyMetric.__init__
      ~CategoricalPrivacyMetric.compute
      ~CategoricalPrivacyMetric.get_subclasses
      ~CategoricalPrivacyMetric.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CategoricalPrivacyMetric.ACCURACY_BASE
      ~CategoricalPrivacyMetric.MODEL
      ~CategoricalPrivacyMetric.MODEL_KWARGS
      ~CategoricalPrivacyMetric.goal
      ~CategoricalPrivacyMetric.max_value
      ~CategoricalPrivacyMetric.min_value
      ~CategoricalPrivacyMetric.name
   
   