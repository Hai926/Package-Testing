﻿sdv.metrics.tabular.GMLogLikelihood
===================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: GMLogLikelihood

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~GMLogLikelihood.__init__
      ~GMLogLikelihood.compute
      ~GMLogLikelihood.get_subclasses
      ~GMLogLikelihood.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~GMLogLikelihood.goal
      ~GMLogLikelihood.max_value
      ~GMLogLikelihood.min_value
      ~GMLogLikelihood.name
   
   