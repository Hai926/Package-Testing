﻿sdv.metrics.relational.KSTestExtended.get\_subclasses
=====================================================

.. currentmodule:: sdv.metrics.relational

.. automethod:: KSTestExtended.get_subclasses