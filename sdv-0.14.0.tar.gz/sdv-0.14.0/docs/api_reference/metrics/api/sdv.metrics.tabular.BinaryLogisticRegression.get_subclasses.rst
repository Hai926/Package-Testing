﻿sdv.metrics.tabular.BinaryLogisticRegression.get\_subclasses
============================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: BinaryLogisticRegression.get_subclasses