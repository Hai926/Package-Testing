﻿sdv.metrics.timeseries.TSFClassifierEfficacy.get\_subclasses
============================================================

.. currentmodule:: sdv.metrics.timeseries

.. automethod:: TSFClassifierEfficacy.get_subclasses