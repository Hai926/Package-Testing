﻿sdv.metrics.relational.SVCDetection
===================================

.. currentmodule:: sdv.metrics.relational

.. autoclass:: SVCDetection

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~SVCDetection.__init__
      ~SVCDetection.compute
      ~SVCDetection.get_subclasses
      ~SVCDetection.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~SVCDetection.goal
      ~SVCDetection.max_value
      ~SVCDetection.min_value
      ~SVCDetection.name
   
   