﻿sdv.metrics.tabular.ContinuousKLDivergence.get\_subclasses
==========================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: ContinuousKLDivergence.get_subclasses