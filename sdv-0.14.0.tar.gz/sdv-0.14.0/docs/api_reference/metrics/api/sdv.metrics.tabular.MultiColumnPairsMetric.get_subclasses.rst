﻿sdv.metrics.tabular.MultiColumnPairsMetric.get\_subclasses
==========================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: MultiColumnPairsMetric.get_subclasses