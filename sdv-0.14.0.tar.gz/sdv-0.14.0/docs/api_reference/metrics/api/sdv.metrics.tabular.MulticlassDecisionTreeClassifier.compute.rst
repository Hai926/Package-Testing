﻿sdv.metrics.tabular.MulticlassDecisionTreeClassifier.compute
============================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: MulticlassDecisionTreeClassifier.compute