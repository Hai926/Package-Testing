﻿sdv.metrics.tabular.CSTest.get\_subclasses
==========================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: CSTest.get_subclasses