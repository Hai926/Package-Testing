﻿sdv.metrics.tabular.BinaryMLPClassifier.compute
===============================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: BinaryMLPClassifier.compute