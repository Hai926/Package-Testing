﻿sdv.metrics.tabular.NumericalSVR
================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: NumericalSVR

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~NumericalSVR.__init__
      ~NumericalSVR.compute
      ~NumericalSVR.get_subclasses
      ~NumericalSVR.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~NumericalSVR.LOSS_FUNCTION_KWARGS
      ~NumericalSVR.MODEL_KWARGS
      ~NumericalSVR.goal
      ~NumericalSVR.max_value
      ~NumericalSVR.min_value
      ~NumericalSVR.name
   
   