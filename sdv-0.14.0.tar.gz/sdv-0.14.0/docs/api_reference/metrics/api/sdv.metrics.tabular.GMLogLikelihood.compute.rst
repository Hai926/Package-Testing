﻿sdv.metrics.tabular.GMLogLikelihood.compute
===========================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: GMLogLikelihood.compute