﻿sdv.metrics.timeseries.LSTMClassifierEfficacy
=============================================

.. currentmodule:: sdv.metrics.timeseries

.. autoclass:: LSTMClassifierEfficacy

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~LSTMClassifierEfficacy.__init__
      ~LSTMClassifierEfficacy.compute
      ~LSTMClassifierEfficacy.get_subclasses
      ~LSTMClassifierEfficacy.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~LSTMClassifierEfficacy.goal
      ~LSTMClassifierEfficacy.max_value
      ~LSTMClassifierEfficacy.min_value
      ~LSTMClassifierEfficacy.name
   
   