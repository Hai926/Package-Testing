﻿sdv.metrics.timeseries.TSFCDetection.get\_subclasses
====================================================

.. currentmodule:: sdv.metrics.timeseries

.. automethod:: TSFCDetection.get_subclasses