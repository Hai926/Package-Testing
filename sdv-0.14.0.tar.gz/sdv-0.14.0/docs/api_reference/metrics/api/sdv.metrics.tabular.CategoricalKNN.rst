﻿sdv.metrics.tabular.CategoricalKNN
==================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: CategoricalKNN

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~CategoricalKNN.__init__
      ~CategoricalKNN.compute
      ~CategoricalKNN.get_subclasses
      ~CategoricalKNN.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CategoricalKNN.ACCURACY_BASE
      ~CategoricalKNN.MODEL_KWARGS
      ~CategoricalKNN.goal
      ~CategoricalKNN.max_value
      ~CategoricalKNN.min_value
      ~CategoricalKNN.name
   
   