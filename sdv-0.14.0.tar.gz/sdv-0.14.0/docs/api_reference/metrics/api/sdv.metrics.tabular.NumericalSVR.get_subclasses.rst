﻿sdv.metrics.tabular.NumericalSVR.get\_subclasses
================================================

.. currentmodule:: sdv.metrics.tabular

.. automethod:: NumericalSVR.get_subclasses