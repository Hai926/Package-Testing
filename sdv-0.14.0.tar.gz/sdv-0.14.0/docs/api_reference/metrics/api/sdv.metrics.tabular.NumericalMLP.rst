﻿sdv.metrics.tabular.NumericalMLP
================================

.. currentmodule:: sdv.metrics.tabular

.. autoclass:: NumericalMLP

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~NumericalMLP.__init__
      ~NumericalMLP.compute
      ~NumericalMLP.get_subclasses
      ~NumericalMLP.normalize
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~NumericalMLP.LOSS_FUNCTION_KWARGS
      ~NumericalMLP.MODEL_KWARGS
      ~NumericalMLP.goal
      ~NumericalMLP.max_value
      ~NumericalMLP.min_value
      ~NumericalMLP.name
   
   