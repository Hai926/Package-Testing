.. _sdv.metrics:

sdv.metrics
===========

.. toctree::
    :maxdepth: 1
    :titlesonly:

    tabular
    relational
    timeseries
    demos
