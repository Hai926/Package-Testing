﻿sdv.constraints.Positive.fit\_transform
=======================================

.. currentmodule:: sdv.constraints

.. automethod:: Positive.fit_transform