﻿sdv.constraints.OneHotEncoding.from\_dict
=========================================

.. currentmodule:: sdv.constraints

.. automethod:: OneHotEncoding.from_dict