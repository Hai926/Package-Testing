﻿sdv.constraints.Negative.fit
============================

.. currentmodule:: sdv.constraints

.. automethod:: Negative.fit