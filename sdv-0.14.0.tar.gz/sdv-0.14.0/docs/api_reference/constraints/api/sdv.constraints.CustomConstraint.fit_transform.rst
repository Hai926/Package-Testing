﻿sdv.constraints.CustomConstraint.fit\_transform
===============================================

.. currentmodule:: sdv.constraints

.. automethod:: CustomConstraint.fit_transform