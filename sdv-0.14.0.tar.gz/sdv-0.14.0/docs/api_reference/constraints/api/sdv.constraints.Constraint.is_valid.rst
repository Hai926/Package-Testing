﻿sdv.constraints.Constraint.is\_valid
====================================

.. currentmodule:: sdv.constraints

.. automethod:: Constraint.is_valid