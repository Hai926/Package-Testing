﻿sdv.constraints.ColumnFormula.to\_dict
======================================

.. currentmodule:: sdv.constraints

.. automethod:: ColumnFormula.to_dict