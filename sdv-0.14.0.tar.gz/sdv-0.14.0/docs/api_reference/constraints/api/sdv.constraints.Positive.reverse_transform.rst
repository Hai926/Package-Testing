﻿sdv.constraints.Positive.reverse\_transform
===========================================

.. currentmodule:: sdv.constraints

.. automethod:: Positive.reverse_transform