﻿sdv.constraints.ColumnFormula.from\_dict
========================================

.. currentmodule:: sdv.constraints

.. automethod:: ColumnFormula.from_dict