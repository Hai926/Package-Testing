﻿sdv.constraints.Unique.fit\_transform
=====================================

.. currentmodule:: sdv.constraints

.. automethod:: Unique.fit_transform