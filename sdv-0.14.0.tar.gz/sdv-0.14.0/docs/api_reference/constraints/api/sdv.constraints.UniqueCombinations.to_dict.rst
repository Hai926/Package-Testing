﻿sdv.constraints.UniqueCombinations.to\_dict
===========================================

.. currentmodule:: sdv.constraints

.. automethod:: UniqueCombinations.to_dict