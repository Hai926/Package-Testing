﻿sdv.constraints.Positive.transform
==================================

.. currentmodule:: sdv.constraints

.. automethod:: Positive.transform