﻿sdv.constraints.ColumnFormula.is\_valid
=======================================

.. currentmodule:: sdv.constraints

.. automethod:: ColumnFormula.is_valid