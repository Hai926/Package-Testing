﻿sdv.constraints.Negative.fit\_transform
=======================================

.. currentmodule:: sdv.constraints

.. automethod:: Negative.fit_transform