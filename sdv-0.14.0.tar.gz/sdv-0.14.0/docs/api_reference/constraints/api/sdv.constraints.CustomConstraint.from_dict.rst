﻿sdv.constraints.CustomConstraint.from\_dict
===========================================

.. currentmodule:: sdv.constraints

.. automethod:: CustomConstraint.from_dict