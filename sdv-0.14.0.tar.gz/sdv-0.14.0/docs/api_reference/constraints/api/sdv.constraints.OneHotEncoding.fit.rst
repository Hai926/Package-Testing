﻿sdv.constraints.OneHotEncoding.fit
==================================

.. currentmodule:: sdv.constraints

.. automethod:: OneHotEncoding.fit