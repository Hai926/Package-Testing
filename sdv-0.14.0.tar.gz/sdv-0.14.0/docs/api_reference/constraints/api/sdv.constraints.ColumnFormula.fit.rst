﻿sdv.constraints.ColumnFormula.fit
=================================

.. currentmodule:: sdv.constraints

.. automethod:: ColumnFormula.fit