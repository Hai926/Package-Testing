﻿sdv.constraints.ColumnFormula
=============================

.. currentmodule:: sdv.constraints

.. autoclass:: ColumnFormula

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~ColumnFormula.__init__
      ~ColumnFormula.filter_valid
      ~ColumnFormula.fit
      ~ColumnFormula.fit_transform
      ~ColumnFormula.from_dict
      ~ColumnFormula.is_valid
      ~ColumnFormula.reverse_transform
      ~ColumnFormula.to_dict
      ~ColumnFormula.transform
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~ColumnFormula.constraint_columns
      ~ColumnFormula.rebuild_columns
   
   