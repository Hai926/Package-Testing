﻿sdv.constraints.UniqueCombinations.filter\_valid
================================================

.. currentmodule:: sdv.constraints

.. automethod:: UniqueCombinations.filter_valid