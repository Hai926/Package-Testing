﻿sdv.constraints.GreaterThan
===========================

.. currentmodule:: sdv.constraints

.. autoclass:: GreaterThan

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~GreaterThan.__init__
      ~GreaterThan.filter_valid
      ~GreaterThan.fit
      ~GreaterThan.fit_transform
      ~GreaterThan.from_dict
      ~GreaterThan.is_valid
      ~GreaterThan.reverse_transform
      ~GreaterThan.to_dict
      ~GreaterThan.transform
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~GreaterThan.constraint_columns
      ~GreaterThan.rebuild_columns
   
   