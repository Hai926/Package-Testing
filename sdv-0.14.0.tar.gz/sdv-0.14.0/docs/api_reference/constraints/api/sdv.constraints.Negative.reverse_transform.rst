﻿sdv.constraints.Negative.reverse\_transform
===========================================

.. currentmodule:: sdv.constraints

.. automethod:: Negative.reverse_transform