﻿sdv.constraints.GreaterThan.transform
=====================================

.. currentmodule:: sdv.constraints

.. automethod:: GreaterThan.transform