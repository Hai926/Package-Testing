﻿sdv.constraints.ColumnFormula.filter\_valid
===========================================

.. currentmodule:: sdv.constraints

.. automethod:: ColumnFormula.filter_valid