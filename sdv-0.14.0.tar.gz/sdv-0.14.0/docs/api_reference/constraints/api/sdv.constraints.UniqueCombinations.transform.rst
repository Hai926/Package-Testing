﻿sdv.constraints.UniqueCombinations.transform
============================================

.. currentmodule:: sdv.constraints

.. automethod:: UniqueCombinations.transform