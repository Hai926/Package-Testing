﻿sdv.constraints.Rounding
========================

.. currentmodule:: sdv.constraints

.. autoclass:: Rounding

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Rounding.__init__
      ~Rounding.filter_valid
      ~Rounding.fit
      ~Rounding.fit_transform
      ~Rounding.from_dict
      ~Rounding.is_valid
      ~Rounding.reverse_transform
      ~Rounding.to_dict
      ~Rounding.transform
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Rounding.constraint_columns
      ~Rounding.rebuild_columns
   
   