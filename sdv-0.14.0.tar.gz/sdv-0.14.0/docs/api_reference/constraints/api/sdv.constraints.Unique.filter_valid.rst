﻿sdv.constraints.Unique.filter\_valid
====================================

.. currentmodule:: sdv.constraints

.. automethod:: Unique.filter_valid