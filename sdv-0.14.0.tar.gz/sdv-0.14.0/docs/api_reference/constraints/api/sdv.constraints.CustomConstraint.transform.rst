﻿sdv.constraints.CustomConstraint.transform
==========================================

.. currentmodule:: sdv.constraints

.. automethod:: CustomConstraint.transform