﻿sdv.constraints.Constraint.filter\_valid
========================================

.. currentmodule:: sdv.constraints

.. automethod:: Constraint.filter_valid