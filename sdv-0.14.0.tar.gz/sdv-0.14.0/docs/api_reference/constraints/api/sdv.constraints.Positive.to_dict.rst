﻿sdv.constraints.Positive.to\_dict
=================================

.. currentmodule:: sdv.constraints

.. automethod:: Positive.to_dict