﻿sdv.constraints.OneHotEncoding.filter\_valid
============================================

.. currentmodule:: sdv.constraints

.. automethod:: OneHotEncoding.filter_valid