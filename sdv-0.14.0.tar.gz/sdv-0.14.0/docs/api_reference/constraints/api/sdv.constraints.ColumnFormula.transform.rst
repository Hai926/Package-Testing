﻿sdv.constraints.ColumnFormula.transform
=======================================

.. currentmodule:: sdv.constraints

.. automethod:: ColumnFormula.transform