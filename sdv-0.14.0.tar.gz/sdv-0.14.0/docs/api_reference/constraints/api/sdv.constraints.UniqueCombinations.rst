﻿sdv.constraints.UniqueCombinations
==================================

.. currentmodule:: sdv.constraints

.. autoclass:: UniqueCombinations

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~UniqueCombinations.__init__
      ~UniqueCombinations.filter_valid
      ~UniqueCombinations.fit
      ~UniqueCombinations.fit_transform
      ~UniqueCombinations.from_dict
      ~UniqueCombinations.is_valid
      ~UniqueCombinations.reverse_transform
      ~UniqueCombinations.to_dict
      ~UniqueCombinations.transform
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~UniqueCombinations.constraint_columns
      ~UniqueCombinations.rebuild_columns
   
   