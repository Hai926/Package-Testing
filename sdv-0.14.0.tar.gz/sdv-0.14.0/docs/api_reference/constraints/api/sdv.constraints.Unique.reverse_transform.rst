﻿sdv.constraints.Unique.reverse\_transform
=========================================

.. currentmodule:: sdv.constraints

.. automethod:: Unique.reverse_transform