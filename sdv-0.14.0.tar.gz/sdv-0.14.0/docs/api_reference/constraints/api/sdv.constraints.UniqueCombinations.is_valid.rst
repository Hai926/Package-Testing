﻿sdv.constraints.UniqueCombinations.is\_valid
============================================

.. currentmodule:: sdv.constraints

.. automethod:: UniqueCombinations.is_valid