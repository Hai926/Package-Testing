﻿sdv.constraints.CustomConstraint.filter\_valid
==============================================

.. currentmodule:: sdv.constraints

.. automethod:: CustomConstraint.filter_valid