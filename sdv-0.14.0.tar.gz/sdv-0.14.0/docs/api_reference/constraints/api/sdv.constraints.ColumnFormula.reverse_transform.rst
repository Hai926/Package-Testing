﻿sdv.constraints.ColumnFormula.reverse\_transform
================================================

.. currentmodule:: sdv.constraints

.. automethod:: ColumnFormula.reverse_transform