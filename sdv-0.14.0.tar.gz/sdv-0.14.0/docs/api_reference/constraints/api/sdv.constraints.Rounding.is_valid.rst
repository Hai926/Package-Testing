﻿sdv.constraints.Rounding.is\_valid
==================================

.. currentmodule:: sdv.constraints

.. automethod:: Rounding.is_valid