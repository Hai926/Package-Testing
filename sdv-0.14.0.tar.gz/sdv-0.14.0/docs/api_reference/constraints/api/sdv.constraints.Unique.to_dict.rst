﻿sdv.constraints.Unique.to\_dict
===============================

.. currentmodule:: sdv.constraints

.. automethod:: Unique.to_dict