﻿sdv.constraints.Negative
========================

.. currentmodule:: sdv.constraints

.. autoclass:: Negative

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Negative.__init__
      ~Negative.filter_valid
      ~Negative.fit
      ~Negative.fit_transform
      ~Negative.from_dict
      ~Negative.is_valid
      ~Negative.reverse_transform
      ~Negative.to_dict
      ~Negative.transform
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Negative.constraint_columns
      ~Negative.rebuild_columns
   
   