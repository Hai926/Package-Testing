﻿sdv.constraints.CustomConstraint.reverse\_transform
===================================================

.. currentmodule:: sdv.constraints

.. automethod:: CustomConstraint.reverse_transform