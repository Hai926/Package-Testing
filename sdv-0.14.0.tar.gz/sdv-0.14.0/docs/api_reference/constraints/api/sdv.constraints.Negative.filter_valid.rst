﻿sdv.constraints.Negative.filter\_valid
======================================

.. currentmodule:: sdv.constraints

.. automethod:: Negative.filter_valid