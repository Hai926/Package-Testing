﻿sdv.constraints.Rounding.to\_dict
=================================

.. currentmodule:: sdv.constraints

.. automethod:: Rounding.to_dict