﻿sdv.constraints.Positive.filter\_valid
======================================

.. currentmodule:: sdv.constraints

.. automethod:: Positive.filter_valid