﻿sdv.constraints.Rounding.from\_dict
===================================

.. currentmodule:: sdv.constraints

.. automethod:: Rounding.from_dict