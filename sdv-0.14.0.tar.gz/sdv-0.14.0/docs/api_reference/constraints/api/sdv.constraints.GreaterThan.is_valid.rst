﻿sdv.constraints.GreaterThan.is\_valid
=====================================

.. currentmodule:: sdv.constraints

.. automethod:: GreaterThan.is_valid