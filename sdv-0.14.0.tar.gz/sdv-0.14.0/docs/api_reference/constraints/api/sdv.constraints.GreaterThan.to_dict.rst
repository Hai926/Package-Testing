﻿sdv.constraints.GreaterThan.to\_dict
====================================

.. currentmodule:: sdv.constraints

.. automethod:: GreaterThan.to_dict