﻿sdv.constraints.OneHotEncoding.transform
========================================

.. currentmodule:: sdv.constraints

.. automethod:: OneHotEncoding.transform