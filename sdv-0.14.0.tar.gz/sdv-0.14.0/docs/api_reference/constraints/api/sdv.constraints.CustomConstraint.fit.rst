﻿sdv.constraints.CustomConstraint.fit
====================================

.. currentmodule:: sdv.constraints

.. automethod:: CustomConstraint.fit