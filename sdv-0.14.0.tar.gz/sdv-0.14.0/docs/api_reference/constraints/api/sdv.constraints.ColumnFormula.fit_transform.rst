﻿sdv.constraints.ColumnFormula.fit\_transform
============================================

.. currentmodule:: sdv.constraints

.. automethod:: ColumnFormula.fit_transform