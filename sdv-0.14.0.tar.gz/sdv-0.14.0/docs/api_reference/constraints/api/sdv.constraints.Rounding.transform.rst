﻿sdv.constraints.Rounding.transform
==================================

.. currentmodule:: sdv.constraints

.. automethod:: Rounding.transform