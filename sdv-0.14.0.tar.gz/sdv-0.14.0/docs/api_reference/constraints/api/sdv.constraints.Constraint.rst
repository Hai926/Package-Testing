﻿sdv.constraints.Constraint
==========================

.. currentmodule:: sdv.constraints

.. autoclass:: Constraint

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Constraint.__init__
      ~Constraint.filter_valid
      ~Constraint.fit
      ~Constraint.fit_transform
      ~Constraint.from_dict
      ~Constraint.is_valid
      ~Constraint.reverse_transform
      ~Constraint.to_dict
      ~Constraint.transform
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Constraint.constraint_columns
      ~Constraint.rebuild_columns
   
   