﻿sdv.constraints.Constraint.reverse\_transform
=============================================

.. currentmodule:: sdv.constraints

.. automethod:: Constraint.reverse_transform