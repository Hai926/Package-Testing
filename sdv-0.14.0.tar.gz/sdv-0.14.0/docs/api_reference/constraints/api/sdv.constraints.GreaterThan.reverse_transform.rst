﻿sdv.constraints.GreaterThan.reverse\_transform
==============================================

.. currentmodule:: sdv.constraints

.. automethod:: GreaterThan.reverse_transform