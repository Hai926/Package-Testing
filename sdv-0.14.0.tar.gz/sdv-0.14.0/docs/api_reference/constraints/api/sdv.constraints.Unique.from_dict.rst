﻿sdv.constraints.Unique.from\_dict
=================================

.. currentmodule:: sdv.constraints

.. automethod:: Unique.from_dict