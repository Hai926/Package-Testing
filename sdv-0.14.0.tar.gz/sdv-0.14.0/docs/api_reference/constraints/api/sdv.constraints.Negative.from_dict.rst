﻿sdv.constraints.Negative.from\_dict
===================================

.. currentmodule:: sdv.constraints

.. automethod:: Negative.from_dict