﻿sdv.constraints.Rounding.fit\_transform
=======================================

.. currentmodule:: sdv.constraints

.. automethod:: Rounding.fit_transform