﻿sdv.constraints.GreaterThan.from\_dict
======================================

.. currentmodule:: sdv.constraints

.. automethod:: GreaterThan.from_dict