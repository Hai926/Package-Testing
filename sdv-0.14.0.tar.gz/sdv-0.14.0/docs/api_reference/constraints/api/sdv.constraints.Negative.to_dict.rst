﻿sdv.constraints.Negative.to\_dict
=================================

.. currentmodule:: sdv.constraints

.. automethod:: Negative.to_dict