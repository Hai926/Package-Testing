﻿sdv.constraints.UniqueCombinations.fit\_transform
=================================================

.. currentmodule:: sdv.constraints

.. automethod:: UniqueCombinations.fit_transform