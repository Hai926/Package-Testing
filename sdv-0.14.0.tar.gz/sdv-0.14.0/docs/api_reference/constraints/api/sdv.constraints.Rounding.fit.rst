﻿sdv.constraints.Rounding.fit
============================

.. currentmodule:: sdv.constraints

.. automethod:: Rounding.fit