﻿sdv.constraints.Positive.is\_valid
==================================

.. currentmodule:: sdv.constraints

.. automethod:: Positive.is_valid