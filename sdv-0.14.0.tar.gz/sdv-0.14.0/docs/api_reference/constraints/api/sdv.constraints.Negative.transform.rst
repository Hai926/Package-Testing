﻿sdv.constraints.Negative.transform
==================================

.. currentmodule:: sdv.constraints

.. automethod:: Negative.transform