﻿sdv.constraints.Unique.transform
================================

.. currentmodule:: sdv.constraints

.. automethod:: Unique.transform