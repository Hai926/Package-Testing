﻿sdv.constraints.OneHotEncoding.fit\_transform
=============================================

.. currentmodule:: sdv.constraints

.. automethod:: OneHotEncoding.fit_transform