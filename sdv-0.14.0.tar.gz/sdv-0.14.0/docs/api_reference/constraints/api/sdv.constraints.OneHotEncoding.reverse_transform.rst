﻿sdv.constraints.OneHotEncoding.reverse\_transform
=================================================

.. currentmodule:: sdv.constraints

.. automethod:: OneHotEncoding.reverse_transform