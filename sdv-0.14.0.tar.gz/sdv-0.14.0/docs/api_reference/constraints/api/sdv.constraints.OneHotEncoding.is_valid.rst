﻿sdv.constraints.OneHotEncoding.is\_valid
========================================

.. currentmodule:: sdv.constraints

.. automethod:: OneHotEncoding.is_valid