﻿sdv.constraints.CustomConstraint.is\_valid
==========================================

.. currentmodule:: sdv.constraints

.. automethod:: CustomConstraint.is_valid