﻿sdv.constraints.Constraint.to\_dict
===================================

.. currentmodule:: sdv.constraints

.. automethod:: Constraint.to_dict