﻿sdv.constraints.GreaterThan.filter\_valid
=========================================

.. currentmodule:: sdv.constraints

.. automethod:: GreaterThan.filter_valid