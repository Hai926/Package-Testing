﻿sdv.constraints.OneHotEncoding.to\_dict
=======================================

.. currentmodule:: sdv.constraints

.. automethod:: OneHotEncoding.to_dict