﻿sdv.constraints.Rounding.reverse\_transform
===========================================

.. currentmodule:: sdv.constraints

.. automethod:: Rounding.reverse_transform