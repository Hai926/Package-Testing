﻿sdv.constraints.OneHotEncoding
==============================

.. currentmodule:: sdv.constraints

.. autoclass:: OneHotEncoding

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~OneHotEncoding.__init__
      ~OneHotEncoding.filter_valid
      ~OneHotEncoding.fit
      ~OneHotEncoding.fit_transform
      ~OneHotEncoding.from_dict
      ~OneHotEncoding.is_valid
      ~OneHotEncoding.reverse_transform
      ~OneHotEncoding.to_dict
      ~OneHotEncoding.transform
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~OneHotEncoding.constraint_columns
      ~OneHotEncoding.rebuild_columns
   
   