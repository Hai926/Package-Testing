﻿sdv.constraints.Constraint.from\_dict
=====================================

.. currentmodule:: sdv.constraints

.. automethod:: Constraint.from_dict