﻿sdv.constraints.UniqueCombinations.fit
======================================

.. currentmodule:: sdv.constraints

.. automethod:: UniqueCombinations.fit