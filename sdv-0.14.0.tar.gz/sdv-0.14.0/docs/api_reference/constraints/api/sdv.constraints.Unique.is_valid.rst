﻿sdv.constraints.Unique.is\_valid
================================

.. currentmodule:: sdv.constraints

.. automethod:: Unique.is_valid