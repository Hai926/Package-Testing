﻿sdv.constraints.Positive.from\_dict
===================================

.. currentmodule:: sdv.constraints

.. automethod:: Positive.from_dict