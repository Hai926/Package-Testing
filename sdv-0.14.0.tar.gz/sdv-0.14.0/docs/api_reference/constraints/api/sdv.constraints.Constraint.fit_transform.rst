﻿sdv.constraints.Constraint.fit\_transform
=========================================

.. currentmodule:: sdv.constraints

.. automethod:: Constraint.fit_transform