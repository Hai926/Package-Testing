﻿sdv.constraints.GreaterThan.fit\_transform
==========================================

.. currentmodule:: sdv.constraints

.. automethod:: GreaterThan.fit_transform