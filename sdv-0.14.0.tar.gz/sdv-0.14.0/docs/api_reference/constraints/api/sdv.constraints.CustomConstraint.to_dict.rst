﻿sdv.constraints.CustomConstraint.to\_dict
=========================================

.. currentmodule:: sdv.constraints

.. automethod:: CustomConstraint.to_dict