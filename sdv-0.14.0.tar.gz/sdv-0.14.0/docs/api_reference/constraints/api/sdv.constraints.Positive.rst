﻿sdv.constraints.Positive
========================

.. currentmodule:: sdv.constraints

.. autoclass:: Positive

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Positive.__init__
      ~Positive.filter_valid
      ~Positive.fit
      ~Positive.fit_transform
      ~Positive.from_dict
      ~Positive.is_valid
      ~Positive.reverse_transform
      ~Positive.to_dict
      ~Positive.transform
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Positive.constraint_columns
      ~Positive.rebuild_columns
   
   