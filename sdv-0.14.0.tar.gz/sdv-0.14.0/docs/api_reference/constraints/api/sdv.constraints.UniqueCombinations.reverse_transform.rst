﻿sdv.constraints.UniqueCombinations.reverse\_transform
=====================================================

.. currentmodule:: sdv.constraints

.. automethod:: UniqueCombinations.reverse_transform