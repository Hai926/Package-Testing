﻿sdv.constraints.Negative.is\_valid
==================================

.. currentmodule:: sdv.constraints

.. automethod:: Negative.is_valid