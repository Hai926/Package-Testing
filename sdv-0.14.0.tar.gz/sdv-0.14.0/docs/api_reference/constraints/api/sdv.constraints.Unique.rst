﻿sdv.constraints.Unique
======================

.. currentmodule:: sdv.constraints

.. autoclass:: Unique

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Unique.__init__
      ~Unique.filter_valid
      ~Unique.fit
      ~Unique.fit_transform
      ~Unique.from_dict
      ~Unique.is_valid
      ~Unique.reverse_transform
      ~Unique.to_dict
      ~Unique.transform
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Unique.constraint_columns
      ~Unique.rebuild_columns
   
   