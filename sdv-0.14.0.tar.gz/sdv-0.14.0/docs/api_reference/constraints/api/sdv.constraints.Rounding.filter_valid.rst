﻿sdv.constraints.Rounding.filter\_valid
======================================

.. currentmodule:: sdv.constraints

.. automethod:: Rounding.filter_valid