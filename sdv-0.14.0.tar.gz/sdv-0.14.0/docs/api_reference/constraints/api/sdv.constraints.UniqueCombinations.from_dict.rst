﻿sdv.constraints.UniqueCombinations.from\_dict
=============================================

.. currentmodule:: sdv.constraints

.. automethod:: UniqueCombinations.from_dict