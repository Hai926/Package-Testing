﻿sdv.constraints.CustomConstraint
================================

.. currentmodule:: sdv.constraints

.. autoclass:: CustomConstraint

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~CustomConstraint.__init__
      ~CustomConstraint.filter_valid
      ~CustomConstraint.fit
      ~CustomConstraint.fit_transform
      ~CustomConstraint.from_dict
      ~CustomConstraint.is_valid
      ~CustomConstraint.reverse_transform
      ~CustomConstraint.to_dict
      ~CustomConstraint.transform
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CustomConstraint.constraint_columns
      ~CustomConstraint.rebuild_columns
   
   