.. _sdv.timeseries.par:

.. currentmodule:: sdv.timeseries.deepecho

PAR
===

.. autosummary::
   :toctree: api/

   PAR
   PAR.fit
   PAR.sample
   PAR.get_metadata
   PAR.save
   PAR.load
