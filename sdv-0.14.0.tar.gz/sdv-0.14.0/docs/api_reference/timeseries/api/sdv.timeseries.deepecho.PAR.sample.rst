﻿sdv.timeseries.deepecho.PAR.sample
==================================

.. currentmodule:: sdv.timeseries.deepecho

.. automethod:: PAR.sample