﻿sdv.timeseries.deepecho.PAR.fit
===============================

.. currentmodule:: sdv.timeseries.deepecho

.. automethod:: PAR.fit