﻿sdv.timeseries.deepecho.PAR.load
================================

.. currentmodule:: sdv.timeseries.deepecho

.. automethod:: PAR.load