﻿sdv.timeseries.deepecho.PAR
===========================

.. currentmodule:: sdv.timeseries.deepecho

.. autoclass:: PAR

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~PAR.__init__
      ~PAR.fit
      ~PAR.get_metadata
      ~PAR.load
      ~PAR.sample
      ~PAR.save
   
   

   
   
   