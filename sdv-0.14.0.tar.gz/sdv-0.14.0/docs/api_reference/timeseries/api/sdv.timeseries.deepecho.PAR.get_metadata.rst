﻿sdv.timeseries.deepecho.PAR.get\_metadata
=========================================

.. currentmodule:: sdv.timeseries.deepecho

.. automethod:: PAR.get_metadata