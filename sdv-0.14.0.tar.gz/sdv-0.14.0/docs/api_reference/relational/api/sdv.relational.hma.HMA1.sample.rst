﻿sdv.relational.hma.HMA1.sample
==============================

.. currentmodule:: sdv.relational.hma

.. automethod:: HMA1.sample