﻿sdv.relational.hma.HMA1
=======================

.. currentmodule:: sdv.relational.hma

.. autoclass:: HMA1

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~HMA1.__init__
      ~HMA1.fit
      ~HMA1.load
      ~HMA1.sample
      ~HMA1.save
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~HMA1.DEFAULT_MODEL_KWARGS
      ~HMA1.metadata
   
   