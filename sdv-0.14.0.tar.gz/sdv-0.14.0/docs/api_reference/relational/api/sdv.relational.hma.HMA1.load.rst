﻿sdv.relational.hma.HMA1.load
============================

.. currentmodule:: sdv.relational.hma

.. automethod:: HMA1.load