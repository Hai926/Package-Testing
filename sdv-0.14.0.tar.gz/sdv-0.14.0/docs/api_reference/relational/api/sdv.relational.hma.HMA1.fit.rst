﻿sdv.relational.hma.HMA1.fit
===========================

.. currentmodule:: sdv.relational.hma

.. automethod:: HMA1.fit