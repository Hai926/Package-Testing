﻿sdv.relational.hma.HMA1.save
============================

.. currentmodule:: sdv.relational.hma

.. automethod:: HMA1.save