.. _sdv.relational.hma1:

.. currentmodule:: sdv.relational.hma

HMA1
====

.. autosummary::
   :toctree: api/

   HMA1
   HMA1.fit
   HMA1.sample
   HMA1.save
   HMA1.load
