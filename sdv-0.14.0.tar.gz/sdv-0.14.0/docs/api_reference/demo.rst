.. _sdv.demo:

sdv.demo
========

.. currentmodule:: sdv.demo

Tabular Demos
~~~~~~~~~~~~~

.. autosummary::
   :toctree: api/

   load_tabular_demo

Relational Demos
~~~~~~~~~~~~~~~~

.. autosummary::
   :toctree: api/

   get_available_demos
   load_demo

Timeseries Demos
~~~~~~~~~~~~~~~~

.. autosummary::
   :toctree: api/

   load_timeseries_demo
