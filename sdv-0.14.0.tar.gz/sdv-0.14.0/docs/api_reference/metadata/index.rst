.. _sdv.metadata:

sdv.metadata
============

.. toctree::
    :maxdepth: 1
    :titlesonly:

    dataset
    table
