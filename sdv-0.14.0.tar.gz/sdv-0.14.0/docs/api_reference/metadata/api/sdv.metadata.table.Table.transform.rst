﻿sdv.metadata.table.Table.transform
==================================

.. currentmodule:: sdv.metadata.table

.. automethod:: Table.transform