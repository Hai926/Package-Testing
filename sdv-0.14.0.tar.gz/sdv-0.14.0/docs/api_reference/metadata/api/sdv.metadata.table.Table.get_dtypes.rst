﻿sdv.metadata.table.Table.get\_dtypes
====================================

.. currentmodule:: sdv.metadata.table

.. automethod:: Table.get_dtypes