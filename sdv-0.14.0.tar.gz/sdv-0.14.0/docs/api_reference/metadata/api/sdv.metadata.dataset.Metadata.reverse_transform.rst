﻿sdv.metadata.dataset.Metadata.reverse\_transform
================================================

.. currentmodule:: sdv.metadata.dataset

.. automethod:: Metadata.reverse_transform