﻿sdv.metadata.table.Table.to\_dict
=================================

.. currentmodule:: sdv.metadata.table

.. automethod:: Table.to_dict