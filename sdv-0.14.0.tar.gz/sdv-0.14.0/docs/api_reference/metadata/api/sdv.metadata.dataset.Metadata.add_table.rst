﻿sdv.metadata.dataset.Metadata.add\_table
========================================

.. currentmodule:: sdv.metadata.dataset

.. automethod:: Metadata.add_table