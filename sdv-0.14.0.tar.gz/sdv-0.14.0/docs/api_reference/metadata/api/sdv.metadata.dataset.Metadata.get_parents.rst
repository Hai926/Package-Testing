﻿sdv.metadata.dataset.Metadata.get\_parents
==========================================

.. currentmodule:: sdv.metadata.dataset

.. automethod:: Metadata.get_parents