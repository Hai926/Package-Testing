﻿sdv.metadata.dataset.Metadata.load\_table
=========================================

.. currentmodule:: sdv.metadata.dataset

.. automethod:: Metadata.load_table