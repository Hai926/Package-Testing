﻿sdv.metadata.dataset.Metadata.add\_relationship
===============================================

.. currentmodule:: sdv.metadata.dataset

.. automethod:: Metadata.add_relationship