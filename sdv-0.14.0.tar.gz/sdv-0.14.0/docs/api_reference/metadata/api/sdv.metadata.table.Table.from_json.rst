﻿sdv.metadata.table.Table.from\_json
===================================

.. currentmodule:: sdv.metadata.table

.. automethod:: Table.from_json