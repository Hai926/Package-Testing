﻿sdv.metadata.table.Table.from\_dict
===================================

.. currentmodule:: sdv.metadata.table

.. automethod:: Table.from_dict