﻿sdv.metadata.dataset.Metadata.get\_fields
=========================================

.. currentmodule:: sdv.metadata.dataset

.. automethod:: Metadata.get_fields