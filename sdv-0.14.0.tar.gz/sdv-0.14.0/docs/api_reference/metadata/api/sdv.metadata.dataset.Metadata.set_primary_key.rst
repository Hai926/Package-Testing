﻿sdv.metadata.dataset.Metadata.set\_primary\_key
===============================================

.. currentmodule:: sdv.metadata.dataset

.. automethod:: Metadata.set_primary_key