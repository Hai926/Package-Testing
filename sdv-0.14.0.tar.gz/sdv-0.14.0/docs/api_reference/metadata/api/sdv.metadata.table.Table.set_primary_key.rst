﻿sdv.metadata.table.Table.set\_primary\_key
==========================================

.. currentmodule:: sdv.metadata.table

.. automethod:: Table.set_primary_key