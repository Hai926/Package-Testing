﻿sdv.metadata.dataset.Metadata.get\_foreign\_keys
================================================

.. currentmodule:: sdv.metadata.dataset

.. automethod:: Metadata.get_foreign_keys