﻿sdv.metadata.table.Table.to\_json
=================================

.. currentmodule:: sdv.metadata.table

.. automethod:: Table.to_json