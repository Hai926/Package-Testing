﻿sdv.metadata.dataset.Metadata.to\_json
======================================

.. currentmodule:: sdv.metadata.dataset

.. automethod:: Metadata.to_json