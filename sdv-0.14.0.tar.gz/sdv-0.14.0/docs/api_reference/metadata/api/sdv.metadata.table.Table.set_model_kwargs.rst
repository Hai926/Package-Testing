﻿sdv.metadata.table.Table.set\_model\_kwargs
===========================================

.. currentmodule:: sdv.metadata.table

.. automethod:: Table.set_model_kwargs