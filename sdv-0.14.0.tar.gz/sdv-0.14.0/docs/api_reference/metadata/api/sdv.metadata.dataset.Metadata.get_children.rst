﻿sdv.metadata.dataset.Metadata.get\_children
===========================================

.. currentmodule:: sdv.metadata.dataset

.. automethod:: Metadata.get_children