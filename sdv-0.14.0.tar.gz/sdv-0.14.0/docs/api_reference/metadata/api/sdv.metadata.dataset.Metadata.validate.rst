﻿sdv.metadata.dataset.Metadata.validate
======================================

.. currentmodule:: sdv.metadata.dataset

.. automethod:: Metadata.validate