﻿sdv.metadata.dataset.Metadata.get\_tables
=========================================

.. currentmodule:: sdv.metadata.dataset

.. automethod:: Metadata.get_tables