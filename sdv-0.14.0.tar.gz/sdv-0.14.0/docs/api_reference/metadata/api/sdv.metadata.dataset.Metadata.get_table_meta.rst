﻿sdv.metadata.dataset.Metadata.get\_table\_meta
==============================================

.. currentmodule:: sdv.metadata.dataset

.. automethod:: Metadata.get_table_meta