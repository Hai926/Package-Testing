﻿sdv.metadata.table.Table.fit
============================

.. currentmodule:: sdv.metadata.table

.. automethod:: Table.fit