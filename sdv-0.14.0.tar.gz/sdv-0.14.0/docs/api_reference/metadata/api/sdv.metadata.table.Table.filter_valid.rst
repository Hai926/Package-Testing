﻿sdv.metadata.table.Table.filter\_valid
======================================

.. currentmodule:: sdv.metadata.table

.. automethod:: Table.filter_valid