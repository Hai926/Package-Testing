﻿sdv.metadata.dataset.Metadata.transform
=======================================

.. currentmodule:: sdv.metadata.dataset

.. automethod:: Metadata.transform