﻿sdv.metadata.dataset.Metadata.add\_field
========================================

.. currentmodule:: sdv.metadata.dataset

.. automethod:: Metadata.add_field