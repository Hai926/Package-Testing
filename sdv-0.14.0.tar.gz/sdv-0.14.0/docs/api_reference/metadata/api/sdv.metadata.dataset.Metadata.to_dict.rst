﻿sdv.metadata.dataset.Metadata.to\_dict
======================================

.. currentmodule:: sdv.metadata.dataset

.. automethod:: Metadata.to_dict