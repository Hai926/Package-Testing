﻿sdv.metadata.table.Table.get\_model\_kwargs
===========================================

.. currentmodule:: sdv.metadata.table

.. automethod:: Table.get_model_kwargs