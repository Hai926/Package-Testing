﻿sdv.metadata.table.Table.reverse\_transform
===========================================

.. currentmodule:: sdv.metadata.table

.. automethod:: Table.reverse_transform