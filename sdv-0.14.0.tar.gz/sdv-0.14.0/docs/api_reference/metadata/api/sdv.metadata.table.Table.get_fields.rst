﻿sdv.metadata.table.Table.get\_fields
====================================

.. currentmodule:: sdv.metadata.table

.. automethod:: Table.get_fields