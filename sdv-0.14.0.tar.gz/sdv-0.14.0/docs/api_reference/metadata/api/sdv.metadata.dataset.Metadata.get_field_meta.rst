﻿sdv.metadata.dataset.Metadata.get\_field\_meta
==============================================

.. currentmodule:: sdv.metadata.dataset

.. automethod:: Metadata.get_field_meta