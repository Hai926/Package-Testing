﻿sdv.metadata.dataset.Metadata.get\_primary\_key
===============================================

.. currentmodule:: sdv.metadata.dataset

.. automethod:: Metadata.get_primary_key