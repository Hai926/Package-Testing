﻿sdv.metadata.dataset.Metadata.load\_tables
==========================================

.. currentmodule:: sdv.metadata.dataset

.. automethod:: Metadata.load_tables