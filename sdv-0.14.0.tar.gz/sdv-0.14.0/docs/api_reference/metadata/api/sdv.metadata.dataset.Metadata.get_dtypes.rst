﻿sdv.metadata.dataset.Metadata.get\_dtypes
=========================================

.. currentmodule:: sdv.metadata.dataset

.. automethod:: Metadata.get_dtypes