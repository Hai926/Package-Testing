.. _sdv.tabular.tvae:

.. currentmodule:: sdv.tabular.ctgan

TVAE
====

.. autosummary::
   :toctree: api/

   TVAE
   TVAE.fit
   TVAE.sample
   TVAE.sample_conditions
   TVAE.sample_remaining_columns
   TVAE.get_metadata
   TVAE.save
   TVAE.load
