.. _sdv.tabular.ctgan:

.. currentmodule:: sdv.tabular.ctgan

CTGAN
=====

.. autosummary::
   :toctree: api/

   CTGAN
   CTGAN.fit
   CTGAN.sample
   CTGAN.sample_conditions
   CTGAN.sample_remaining_columns
   CTGAN.get_metadata
   CTGAN.save
   CTGAN.load
