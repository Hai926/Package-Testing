.. _sdv.tabular:

sdv.tabular
===========

.. toctree::
    :maxdepth: 1
    :titlesonly:

    copulas
    copulagan
    ctgan
    tvae
