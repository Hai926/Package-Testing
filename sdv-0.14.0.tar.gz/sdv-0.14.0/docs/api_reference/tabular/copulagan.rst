.. _sdv.tabular.copulagan:

.. currentmodule:: sdv.tabular.copulagan

CopulaGAN
=========

.. autosummary::
   :toctree: api/

   CopulaGAN
   CopulaGAN.fit
   CopulaGAN.sample
   CopulaGAN.sample_conditions
   CopulaGAN.sample_remaining_columns
   CopulaGAN.get_metadata
   CopulaGAN.get_distributions
   CopulaGAN.save
   CopulaGAN.load
