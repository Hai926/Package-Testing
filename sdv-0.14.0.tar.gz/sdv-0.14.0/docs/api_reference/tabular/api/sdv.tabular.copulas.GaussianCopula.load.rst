﻿sdv.tabular.copulas.GaussianCopula.load
=======================================

.. currentmodule:: sdv.tabular.copulas

.. automethod:: GaussianCopula.load