﻿sdv.tabular.ctgan.CTGAN.sample
==============================

.. currentmodule:: sdv.tabular.ctgan

.. automethod:: CTGAN.sample