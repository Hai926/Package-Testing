﻿sdv.tabular.copulas.GaussianCopula.sample\_remaining\_columns
=============================================================

.. currentmodule:: sdv.tabular.copulas

.. automethod:: GaussianCopula.sample_remaining_columns