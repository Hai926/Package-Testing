﻿sdv.tabular.copulas.GaussianCopula.get\_distributions
=====================================================

.. currentmodule:: sdv.tabular.copulas

.. automethod:: GaussianCopula.get_distributions