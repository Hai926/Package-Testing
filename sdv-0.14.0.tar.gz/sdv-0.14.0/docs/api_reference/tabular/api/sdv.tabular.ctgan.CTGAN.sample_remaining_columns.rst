﻿sdv.tabular.ctgan.CTGAN.sample\_remaining\_columns
==================================================

.. currentmodule:: sdv.tabular.ctgan

.. automethod:: CTGAN.sample_remaining_columns