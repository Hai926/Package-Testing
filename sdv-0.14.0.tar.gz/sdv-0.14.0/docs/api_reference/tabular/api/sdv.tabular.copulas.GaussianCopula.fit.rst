﻿sdv.tabular.copulas.GaussianCopula.fit
======================================

.. currentmodule:: sdv.tabular.copulas

.. automethod:: GaussianCopula.fit