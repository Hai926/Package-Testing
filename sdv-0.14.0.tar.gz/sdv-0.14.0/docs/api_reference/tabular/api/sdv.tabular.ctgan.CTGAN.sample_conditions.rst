﻿sdv.tabular.ctgan.CTGAN.sample\_conditions
==========================================

.. currentmodule:: sdv.tabular.ctgan

.. automethod:: CTGAN.sample_conditions