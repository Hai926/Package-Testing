﻿sdv.tabular.copulagan.CopulaGAN.get\_metadata
=============================================

.. currentmodule:: sdv.tabular.copulagan

.. automethod:: CopulaGAN.get_metadata