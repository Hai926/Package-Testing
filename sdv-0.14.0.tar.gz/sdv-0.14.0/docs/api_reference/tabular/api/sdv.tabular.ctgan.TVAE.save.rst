﻿sdv.tabular.ctgan.TVAE.save
===========================

.. currentmodule:: sdv.tabular.ctgan

.. automethod:: TVAE.save