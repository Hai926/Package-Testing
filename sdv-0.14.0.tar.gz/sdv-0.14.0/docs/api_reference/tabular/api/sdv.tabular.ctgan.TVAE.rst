﻿sdv.tabular.ctgan.TVAE
======================

.. currentmodule:: sdv.tabular.ctgan

.. autoclass:: TVAE

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TVAE.__init__
      ~TVAE.fit
      ~TVAE.get_metadata
      ~TVAE.get_parameters
      ~TVAE.load
      ~TVAE.sample
      ~TVAE.sample_conditions
      ~TVAE.sample_remaining_columns
      ~TVAE.save
      ~TVAE.set_parameters
   
   

   
   
   