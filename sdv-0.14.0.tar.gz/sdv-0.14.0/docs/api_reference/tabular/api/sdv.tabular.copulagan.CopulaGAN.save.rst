﻿sdv.tabular.copulagan.CopulaGAN.save
====================================

.. currentmodule:: sdv.tabular.copulagan

.. automethod:: CopulaGAN.save