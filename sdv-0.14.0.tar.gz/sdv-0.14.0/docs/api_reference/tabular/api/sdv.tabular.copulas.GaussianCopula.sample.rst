﻿sdv.tabular.copulas.GaussianCopula.sample
=========================================

.. currentmodule:: sdv.tabular.copulas

.. automethod:: GaussianCopula.sample