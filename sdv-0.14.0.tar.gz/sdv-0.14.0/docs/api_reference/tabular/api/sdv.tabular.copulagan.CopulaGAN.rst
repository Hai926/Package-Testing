﻿sdv.tabular.copulagan.CopulaGAN
===============================

.. currentmodule:: sdv.tabular.copulagan

.. autoclass:: CopulaGAN

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~CopulaGAN.__init__
      ~CopulaGAN.fit
      ~CopulaGAN.get_distributions
      ~CopulaGAN.get_metadata
      ~CopulaGAN.get_parameters
      ~CopulaGAN.load
      ~CopulaGAN.sample
      ~CopulaGAN.sample_conditions
      ~CopulaGAN.sample_remaining_columns
      ~CopulaGAN.save
      ~CopulaGAN.set_parameters
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~CopulaGAN.DEFAULT_DISTRIBUTION
   
   