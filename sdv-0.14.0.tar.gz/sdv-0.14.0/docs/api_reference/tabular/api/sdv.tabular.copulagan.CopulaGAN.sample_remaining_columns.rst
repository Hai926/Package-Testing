﻿sdv.tabular.copulagan.CopulaGAN.sample\_remaining\_columns
==========================================================

.. currentmodule:: sdv.tabular.copulagan

.. automethod:: CopulaGAN.sample_remaining_columns