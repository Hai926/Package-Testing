﻿sdv.tabular.ctgan.CTGAN.load
============================

.. currentmodule:: sdv.tabular.ctgan

.. automethod:: CTGAN.load