﻿sdv.tabular.copulas.GaussianCopula.get\_likelihood
==================================================

.. currentmodule:: sdv.tabular.copulas

.. automethod:: GaussianCopula.get_likelihood