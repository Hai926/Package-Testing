﻿sdv.tabular.ctgan.CTGAN.save
============================

.. currentmodule:: sdv.tabular.ctgan

.. automethod:: CTGAN.save