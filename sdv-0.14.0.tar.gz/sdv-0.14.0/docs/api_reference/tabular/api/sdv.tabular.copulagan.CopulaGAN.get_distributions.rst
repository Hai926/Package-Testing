﻿sdv.tabular.copulagan.CopulaGAN.get\_distributions
==================================================

.. currentmodule:: sdv.tabular.copulagan

.. automethod:: CopulaGAN.get_distributions