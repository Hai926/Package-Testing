﻿sdv.tabular.ctgan.CTGAN.fit
===========================

.. currentmodule:: sdv.tabular.ctgan

.. automethod:: CTGAN.fit