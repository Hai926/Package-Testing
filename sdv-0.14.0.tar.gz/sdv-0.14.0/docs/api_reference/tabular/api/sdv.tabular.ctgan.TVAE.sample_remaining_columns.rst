﻿sdv.tabular.ctgan.TVAE.sample\_remaining\_columns
=================================================

.. currentmodule:: sdv.tabular.ctgan

.. automethod:: TVAE.sample_remaining_columns