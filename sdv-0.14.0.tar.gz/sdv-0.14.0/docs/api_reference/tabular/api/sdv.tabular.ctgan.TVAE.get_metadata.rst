﻿sdv.tabular.ctgan.TVAE.get\_metadata
====================================

.. currentmodule:: sdv.tabular.ctgan

.. automethod:: TVAE.get_metadata