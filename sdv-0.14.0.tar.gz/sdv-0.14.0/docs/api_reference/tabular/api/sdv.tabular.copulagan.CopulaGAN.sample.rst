﻿sdv.tabular.copulagan.CopulaGAN.sample
======================================

.. currentmodule:: sdv.tabular.copulagan

.. automethod:: CopulaGAN.sample