﻿sdv.tabular.ctgan.TVAE.sample
=============================

.. currentmodule:: sdv.tabular.ctgan

.. automethod:: TVAE.sample