﻿sdv.tabular.copulas.GaussianCopula.get\_parameters
==================================================

.. currentmodule:: sdv.tabular.copulas

.. automethod:: GaussianCopula.get_parameters