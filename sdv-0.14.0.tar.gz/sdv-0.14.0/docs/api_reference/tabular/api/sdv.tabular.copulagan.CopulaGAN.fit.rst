﻿sdv.tabular.copulagan.CopulaGAN.fit
===================================

.. currentmodule:: sdv.tabular.copulagan

.. automethod:: CopulaGAN.fit