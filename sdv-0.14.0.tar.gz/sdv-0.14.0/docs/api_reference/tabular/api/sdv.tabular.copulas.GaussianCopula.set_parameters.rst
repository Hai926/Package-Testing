﻿sdv.tabular.copulas.GaussianCopula.set\_parameters
==================================================

.. currentmodule:: sdv.tabular.copulas

.. automethod:: GaussianCopula.set_parameters