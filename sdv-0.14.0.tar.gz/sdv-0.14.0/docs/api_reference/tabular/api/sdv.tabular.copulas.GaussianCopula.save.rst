﻿sdv.tabular.copulas.GaussianCopula.save
=======================================

.. currentmodule:: sdv.tabular.copulas

.. automethod:: GaussianCopula.save