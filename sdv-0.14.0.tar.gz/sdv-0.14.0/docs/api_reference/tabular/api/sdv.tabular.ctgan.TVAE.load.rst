﻿sdv.tabular.ctgan.TVAE.load
===========================

.. currentmodule:: sdv.tabular.ctgan

.. automethod:: TVAE.load