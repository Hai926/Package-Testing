﻿sdv.tabular.ctgan.TVAE.sample\_conditions
=========================================

.. currentmodule:: sdv.tabular.ctgan

.. automethod:: TVAE.sample_conditions