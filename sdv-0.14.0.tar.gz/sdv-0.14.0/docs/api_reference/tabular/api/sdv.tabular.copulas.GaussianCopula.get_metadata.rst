﻿sdv.tabular.copulas.GaussianCopula.get\_metadata
================================================

.. currentmodule:: sdv.tabular.copulas

.. automethod:: GaussianCopula.get_metadata