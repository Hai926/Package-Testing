﻿sdv.tabular.ctgan.CTGAN
=======================

.. currentmodule:: sdv.tabular.ctgan

.. autoclass:: CTGAN

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~CTGAN.__init__
      ~CTGAN.fit
      ~CTGAN.get_metadata
      ~CTGAN.get_parameters
      ~CTGAN.load
      ~CTGAN.sample
      ~CTGAN.sample_conditions
      ~CTGAN.sample_remaining_columns
      ~CTGAN.save
      ~CTGAN.set_parameters
   
   

   
   
   