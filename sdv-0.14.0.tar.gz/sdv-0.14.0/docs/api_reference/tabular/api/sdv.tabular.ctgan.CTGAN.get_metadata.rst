﻿sdv.tabular.ctgan.CTGAN.get\_metadata
=====================================

.. currentmodule:: sdv.tabular.ctgan

.. automethod:: CTGAN.get_metadata