﻿sdv.tabular.copulagan.CopulaGAN.load
====================================

.. currentmodule:: sdv.tabular.copulagan

.. automethod:: CopulaGAN.load