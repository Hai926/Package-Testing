.. _developer_sdv:

SDV
===

SDV is the library which provides a user friendly interface to access all the
different functionalities of The Synthetic Data Vault Project.

SDV is organized around the following concepts:

.. toctree::
    :maxdepth: 3

    tabular
    constraints
    metadata
