"""Relational models subpackage."""

from sdv.relational.hma import HMA1

__all__ = (
    'HMA1',
)
