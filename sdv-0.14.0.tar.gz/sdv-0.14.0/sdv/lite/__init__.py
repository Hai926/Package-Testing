"""SDV lite package that contains model presets."""

from sdv.lite.tabular import TabularPreset

__all__ = (
    'TabularPreset',
)
