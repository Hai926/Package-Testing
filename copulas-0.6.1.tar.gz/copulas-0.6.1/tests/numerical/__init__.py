"""Copulas numerical testing module."""
