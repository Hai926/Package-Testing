"""Copulas numerical fit testing module."""
