"""Copulas end-to-end testing module."""
