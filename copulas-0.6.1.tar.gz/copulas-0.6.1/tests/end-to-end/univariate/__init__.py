"""Copulas univariate end-to-end testing module."""
