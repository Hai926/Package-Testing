"""Copulas bivariate end-to-end testing module."""
