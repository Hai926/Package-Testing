"""Copulas unit testing module."""
