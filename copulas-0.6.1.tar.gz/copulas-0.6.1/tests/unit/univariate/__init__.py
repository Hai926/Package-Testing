"""Copulas univariate unit testing module."""
