"""Copulas bivariate unit testing module."""
