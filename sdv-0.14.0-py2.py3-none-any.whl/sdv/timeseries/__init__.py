"""Models for timeseries data."""

from sdv.timeseries.deepecho import PAR

__all__ = (
    'PAR',
)
