"""Constraint Exceptions."""


class MissingConstraintColumnError(Exception):
    """Error to use when constraint is provided a table with missing columns."""
