History
-------

1.0.3 (2016-06-09)
^^^^^^^^^^^^^^^^^^

- Fixed the compilation with Python 3.5 on Windows.


1.0.2 (2016-06-06)
^^^^^^^^^^^^^^^^^^

- Added support for Python 3.


1.0.1 (2015-11-15)
^^^^^^^^^^^^^^^^^^

- Improvements to the build process on MS Windows;
- Automatic upload of release files to PyPI using Appveyor.


1.0.0 (2015-10-27)
^^^^^^^^^^^^^^^^^^

- Spun off these binding from `PyInterval
  <https://github.com/taschini/pyinterval>`_, a project for interval
  arithmetic in Python.
- First release on PyPI.
